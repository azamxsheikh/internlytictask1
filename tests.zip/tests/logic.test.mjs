// Automated tests for the pure logic of the app (no browser needed).
// Run with:  npm test      (uses Node's built-in test runner)

import test from "node:test";
import assert from "node:assert/strict";

import { SEED_CATEGORIES, SEED_QUESTIONS } from "../src/data/seedData.js";
import {
  scoreQuiz,
  getPerformanceSummary,
  topicsToPractice,
  computeStats,
  bestByCategory,
  PASS_PERCENTAGE,
} from "../src/utils/scoring.js";
import {
  validateQuestion,
  validateCategory,
  validateAdminForm,
  validateStudentName,
  slugify,
} from "../src/utils/validators.js";
import { hashPassword, makeSalt } from "../src/utils/demoAuth.js";
import { readJSON, writeJSON, clearAllAppData, createId } from "../src/utils/storage.js";

// ---------------------------------------------------------------- seed data
test("seed data has the four required categories", () => {
  assert.deepEqual(
    SEED_CATEGORIES.map((c) => c.name),
    ["HTML", "CSS", "JavaScript", "React"]
  );
});

test("every category has at least 10 questions", () => {
  SEED_CATEGORIES.forEach((cat) => {
    const count = SEED_QUESTIONS.filter((x) => x.categoryId === cat.id).length;
    assert.ok(count >= 10, `${cat.name} has only ${count} questions`);
  });
});

test("every seed question is well-formed", () => {
  const ids = new Set();
  SEED_QUESTIONS.forEach((item) => {
    assert.ok(!ids.has(item.id), `duplicate id ${item.id}`);
    ids.add(item.id);
    assert.equal(item.options.length, 4, `${item.id} needs 4 options`);
    assert.equal(new Set(item.options.map((o) => o.toLowerCase())).size, 4, `${item.id} has duplicate options`);
    assert.ok(Number.isInteger(item.correctIndex) && item.correctIndex >= 0 && item.correctIndex <= 3);
    assert.ok(item.topic.length > 1 && item.text.length >= 10);
    assert.ok(SEED_CATEGORIES.some((c) => c.id === item.categoryId));
    // Seed questions must satisfy the same rules the admin form enforces.
    assert.deepEqual(validateQuestion(item, SEED_CATEGORIES), {}, `${item.id} fails validation`);
  });
});

// ------------------------------------------------------------------ scoring
const htmlQuestions = SEED_QUESTIONS.filter((x) => x.categoryId === "html");

test("scoreQuiz: perfect score", () => {
  const answers = Object.fromEntries(htmlQuestions.map((x) => [x.id, x.correctIndex]));
  const r = scoreQuiz(htmlQuestions, answers);
  assert.equal(r.total, 10);
  assert.equal(r.correct, 10);
  assert.equal(r.incorrect, 0);
  assert.equal(r.percentage, 100);
  assert.equal(r.passed, true);
});

test("scoreQuiz: wrong and unanswered questions count as incorrect", () => {
  const answers = {};
  htmlQuestions.slice(0, 6).forEach((x) => (answers[x.id] = x.correctIndex)); // 6 right
  answers[htmlQuestions[6].id] = (htmlQuestions[6].correctIndex + 1) % 4; // 1 wrong
  const r = scoreQuiz(htmlQuestions, answers); // 3 unanswered
  assert.equal(r.correct, 6);
  assert.equal(r.incorrect, 4);
  assert.equal(r.unanswered, 3);
  assert.equal(r.percentage, 60);
  assert.equal(r.passed, true); // exactly the pass mark
  assert.equal(r.review[6].isCorrect, false);
  assert.equal(r.review[9].selectedIndex, null);
});

test("scoreQuiz: just below the pass mark fails", () => {
  const answers = {};
  htmlQuestions.slice(0, 5).forEach((x) => (answers[x.id] = x.correctIndex));
  const r = scoreQuiz(htmlQuestions, answers);
  assert.equal(r.percentage, 50);
  assert.equal(r.passed, false);
  assert.ok(PASS_PERCENTAGE === 60);
});

test("scoreQuiz: option index 0 is treated as an answer, not as 'blank'", () => {
  const first = htmlQuestions[0];
  const r = scoreQuiz([first], { [first.id]: 0 });
  assert.equal(r.review[0].selectedIndex, 0);
  assert.equal(r.unanswered, 0);
});

test("scoreQuiz: empty quiz does not divide by zero", () => {
  const r = scoreQuiz([], {});
  assert.equal(r.percentage, 0);
  assert.equal(r.total, 0);
});

test("topicsToPractice ranks the weakest topics first", () => {
  const review = [
    { topic: "Forms", isCorrect: false },
    { topic: "Forms", isCorrect: false },
    { topic: "Lists", isCorrect: false },
    { topic: "Tables", isCorrect: true },
  ];
  const result = topicsToPractice(review);
  assert.deepEqual(result.map((t) => t.topic), ["Forms", "Lists"]);
  assert.equal(result[0].wrong, 2);
});

test("performance summary changes with the score", () => {
  assert.equal(getPerformanceSummary(95).level, "Outstanding");
  assert.equal(getPerformanceSummary(60).level, "Good");
  assert.equal(getPerformanceSummary(10).level, "Keep practising");
});

test("dashboard statistics", () => {
  assert.deepEqual(computeStats([]), { total: 0, average: 0, best: 0, passed: 0 });
  const attempts = [
    { categoryId: "html", percentage: 80, passed: true },
    { categoryId: "html", percentage: 40, passed: false },
    { categoryId: "css", percentage: 60, passed: true },
  ];
  const stats = computeStats(attempts);
  assert.equal(stats.total, 3);
  assert.equal(stats.average, 60);
  assert.equal(stats.best, 80);
  assert.equal(stats.passed, 2);
  assert.deepEqual(bestByCategory(attempts), { html: 80, css: 60 });
});

// --------------------------------------------------------------- validators
const goodQuestion = {
  categoryId: "html",
  text: "Which tag creates a paragraph?",
  options: ["<p>", "<para>", "<pg>", "<text>"],
  correctIndex: 0,
  topic: "Text",
  explanation: "",
};

test("validateQuestion accepts a valid question", () => {
  assert.deepEqual(validateQuestion(goodQuestion, SEED_CATEGORIES), {});
});

test("validateQuestion rejects bad input", () => {
  const errors = validateQuestion(
    { categoryId: "nope", text: "short", options: ["a", "A", "", "d"], correctIndex: null, topic: "" },
    SEED_CATEGORIES
  );
  assert.ok(errors.categoryId && errors.text && errors.options && errors.correctIndex && errors.topic);
  assert.ok(errors.options[1], "duplicate option should be flagged");
  assert.ok(errors.options[2], "empty option should be flagged");
});

test("validateCategory: unique names, editing keeps own name", () => {
  const data = { name: "html", description: "A long enough description.", icon: "code" };
  assert.ok(validateCategory(data, SEED_CATEGORIES).name, "duplicate name must fail");
  assert.deepEqual(validateCategory(data, SEED_CATEGORIES, "html"), {});
  assert.ok(validateCategory({ ...data, name: "X" }, SEED_CATEGORIES).name);
  assert.ok(validateCategory({ ...data, description: "short" }, SEED_CATEGORIES, "html").description);
});

test("validateAdminForm: login vs. setup rules", () => {
  assert.ok(validateAdminForm({ email: "bad", password: "" }, false).email);
  assert.deepEqual(validateAdminForm({ email: "a@b.co", password: "x" }, false), {});
  assert.ok(validateAdminForm({ email: "a@b.co", password: "short1", confirm: "short1" }, true).password);
  assert.ok(validateAdminForm({ email: "a@b.co", password: "onlyletters", confirm: "onlyletters" }, true).password);
  assert.ok(validateAdminForm({ email: "a@b.co", password: "goodpass1", confirm: "other" }, true).confirm);
  assert.deepEqual(validateAdminForm({ email: "a@b.co", password: "goodpass1", confirm: "goodpass1" }, true), {});
});

test("validateStudentName and slugify", () => {
  assert.ok(validateStudentName("A"));
  assert.equal(validateStudentName("Ayesha"), "");
  assert.equal(slugify("  Node JS & Express! "), "node-js-express");
});

// ------------------------------------------------------------------ hashing
test("password hashing is salted and deterministic per salt", async () => {
  const salt = makeSalt();
  const a = await hashPassword("secret123", salt);
  const b = await hashPassword("secret123", salt);
  const c = await hashPassword("secret123", makeSalt());
  assert.equal(a, b);
  assert.notEqual(a, c);
  assert.equal(a.length, 64);
});

// ------------------------------------------------------------------ storage
test("storage wrapper: round trip, fallback on corrupted data, clear", () => {
  const data = new Map();
  globalThis.localStorage = {
    getItem: (k) => (data.has(k) ? data.get(k) : null),
    setItem: (k, v) => void data.set(k, String(v)),
    removeItem: (k) => void data.delete(k),
    key: (i) => [...data.keys()][i] ?? null,
    get length() {
      return data.size;
    },
  };
  // Object.keys(localStorage) is used by clearAllAppData, so expose keys as props.
  const proxy = new Proxy(globalThis.localStorage, {
    ownKeys: () => [...data.keys()],
    getOwnPropertyDescriptor: () => ({ enumerable: true, configurable: true }),
  });
  globalThis.localStorage = proxy;

  assert.equal(writeJSON("attempts", [{ id: 1 }]), true);
  assert.deepEqual(readJSON("attempts", []), [{ id: 1 }]);

  data.set("internlytic:v1:attempts", "{not valid json");
  assert.deepEqual(readJSON("attempts", ["fallback"]), ["fallback"]);

  clearAllAppData();
  assert.equal(readJSON("attempts", "gone"), "gone");
  assert.notEqual(createId("q"), createId("q"));

  delete globalThis.localStorage;
  assert.equal(writeJSON("x", 1), false, "no storage -> returns false instead of throwing");
});
