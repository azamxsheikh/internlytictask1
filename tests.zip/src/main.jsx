// main.jsx - the entry point. It mounts <App /> and wraps it in the providers
// that share data across the whole app:
//   ErrorBoundary -> catches crashes
//   BrowserRouter -> enables page routing (URLs like /quizzes, /admin)
//   ToastProvider -> notifications
//   AuthProvider  -> demo admin login state
//   AppProvider   -> categories, questions and attempt history
import React from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App.jsx";
import ErrorBoundary from "./components/ErrorBoundary.jsx";
import { ToastProvider } from "./context/ToastContext.jsx";
import { AuthProvider } from "./context/AuthContext.jsx";
import { AppProvider } from "./context/AppContext.jsx";
import "./styles/index.css";

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <ErrorBoundary>
      <BrowserRouter>
        <ToastProvider>
          <AuthProvider>
            <AppProvider>
              <App />
            </AppProvider>
          </AuthProvider>
        </ToastProvider>
      </BrowserRouter>
    </ErrorBoundary>
  </React.StrictMode>
);
