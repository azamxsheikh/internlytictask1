// AdminLayout - sidebar links and top bar for the admin area.

import { Link, useNavigate } from "react-router-dom";
import Shell from "../Shell.jsx";
import Icon from "../Icon.jsx";
import { useAuth } from "../../context/AuthContext.jsx";
import { useToast } from "../../context/ToastContext.jsx";

const LINKS = [
  { to: "/admin", label: "Overview", icon: "dashboard", end: true },
  { to: "/admin/questions", label: "Questions", icon: "list" },
  { to: "/admin/categories", label: "Categories", icon: "layers" },
];

export default function AdminLayout() {
  const { adminEmail, logout } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();

  function handleLogout() {
    logout();
    toast.info("You have been signed out.");
    navigate("/admin/login", { replace: true });
  }

  return (
    <Shell
      areaLabel="Admin Panel"
      links={LINKS}
      topRight={
        <>
          <span className="user-chip">
            <Icon name="shield" size={18} />
            <span className="user-chip-text">{adminEmail}</span>
          </span>
          <button type="button" className="btn btn-secondary btn-sm" onClick={handleLogout}>
            <Icon name="logout" size={16} /> Sign out
          </button>
        </>
      }
      footer={
        <Link to="/" className="footer-link">
          <Icon name="arrowLeft" size={16} /> Back to student site
        </Link>
      }
    />
  );
}
