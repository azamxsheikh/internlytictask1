// StudentLayout - sidebar links and top bar for the student area.

import { Link } from "react-router-dom";
import Shell from "../Shell.jsx";
import Icon from "../Icon.jsx";
import { useApp } from "../../context/AppContext.jsx";

const LINKS = [
  { to: "/", label: "Dashboard", icon: "home", end: true },
  { to: "/quizzes", label: "Take a Quiz", icon: "quiz" },
  { to: "/history", label: "Attempt History", icon: "history" },
];

export default function StudentLayout() {
  const { studentName } = useApp();
  return (
    <Shell
      areaLabel="Student Panel"
      links={LINKS}
      topRight={
        <span className="user-chip">
          <Icon name="user" size={18} />
          <span>{studentName}</span>
        </span>
      }
      footer={
        <Link to="/admin/login" className="footer-link">
          <Icon name="lock" size={16} /> Admin login
        </Link>
      }
    />
  );
}
