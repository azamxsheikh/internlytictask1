// CategoryFormModal - the "Add category" / "Edit category" form for admins.

import { useState } from "react";
import Modal from "./Modal.jsx";
import Field from "./Field.jsx";
import Icon, { CATEGORY_ICONS } from "./Icon.jsx";
import { validateCategory } from "../utils/validators.js";

export default function CategoryFormModal({ initial, categories, onSave, onClose }) {
  const isEdit = Boolean(initial);
  const [form, setForm] = useState({
    name: initial?.name || "",
    description: initial?.description || "",
    icon: initial?.icon || CATEGORY_ICONS[0],
  });
  const [errors, setErrors] = useState({});

  const setField = (name, value) => setForm((f) => ({ ...f, [name]: value }));

  function handleSubmit(event) {
    event.preventDefault();
    const found = validateCategory(form, categories, initial?.id ?? null);
    setErrors(found);
    if (Object.keys(found).length > 0) return;
    onSave(form);
  }

  return (
    <Modal title={isEdit ? "Edit category" : "Add new category"} onClose={onClose}>
      <form onSubmit={handleSubmit} noValidate>
        <Field id="c-name" label="Category name" error={errors.name} required>
          <input
            id="c-name"
            type="text"
            value={form.name}
            onChange={(e) => setField("name", e.target.value)}
            aria-invalid={Boolean(errors.name)}
            aria-describedby={errors.name ? "c-name-msg" : undefined}
          />
        </Field>

        <Field
          id="c-description"
          label="Description"
          error={errors.description}
          hint={`${form.description.trim().length}/150 characters`}
          required
        >
          <textarea
            id="c-description"
            rows={3}
            value={form.description}
            onChange={(e) => setField("description", e.target.value)}
            aria-invalid={Boolean(errors.description)}
            aria-describedby="c-description-msg"
          />
        </Field>

        <fieldset className="icon-fieldset">
          <legend>Icon</legend>
          <div className="icon-picker">
            {CATEGORY_ICONS.map((name) => (
              <label key={name} className={`icon-choice ${form.icon === name ? "selected" : ""}`}>
                <input
                  type="radio"
                  name="icon"
                  value={name}
                  checked={form.icon === name}
                  onChange={() => setField("icon", name)}
                  className="sr-only"
                />
                <Icon name={name} size={22} />
                <span className="sr-only">{name} icon</span>
              </label>
            ))}
          </div>
          {errors.icon && (
            <p className="field-error" role="alert">
              {errors.icon}
            </p>
          )}
        </fieldset>

        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary">
            {isEdit ? "Save changes" : "Add category"}
          </button>
        </div>
      </form>
    </Modal>
  );
}
