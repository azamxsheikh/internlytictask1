// StatCard - a number with a label and icon, used on both dashboards.

import Icon from "./Icon.jsx";

export default function StatCard({ icon, label, value, hint, tone = "teal" }) {
  return (
    <div className="card stat-card">
      <div className={`stat-icon tone-${tone}`}>
        <Icon name={icon} size={22} />
      </div>
      <div>
        <p className="stat-label">{label}</p>
        <p className="stat-value">{value}</p>
        {hint && <p className="stat-hint">{hint}</p>}
      </div>
    </div>
  );
}
