// CategoryCard - one quiz category with its question count, best score and a Start button.

import { Link } from "react-router-dom";
import Icon from "./Icon.jsx";
import { formatPercent } from "../utils/format.js";

export default function CategoryCard({ category, questionCount, bestScore }) {
  const hasQuestions = questionCount > 0;
  return (
    <article className="card category-card">
      <div className="category-top">
        <div className="category-icon">
          <Icon name={category.icon} size={24} />
        </div>
        <span className="badge">{questionCount} question{questionCount === 1 ? "" : "s"}</span>
      </div>
      <h3>{category.name}</h3>
      <p className="muted">{category.description}</p>
      <div className="category-footer">
        <span className="small muted">
          {bestScore === undefined ? "Not attempted yet" : `Best: ${formatPercent(bestScore)}`}
        </span>
        {hasQuestions ? (
          <Link className="btn btn-primary btn-sm" to={`/quiz/${category.id}`} aria-label={`Start ${category.name} quiz`}>
            {bestScore === undefined ? "Start quiz" : "Retake"} <Icon name="arrowRight" size={16} />
          </Link>
        ) : (
          <button type="button" className="btn btn-secondary btn-sm" disabled>
            No questions yet
          </button>
        )}
      </div>
    </article>
  );
}
