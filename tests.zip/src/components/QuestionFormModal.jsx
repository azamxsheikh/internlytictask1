// QuestionFormModal - the "Add question" / "Edit question" form for admins.
// It validates every field before saving and shows an error under each field.

import { useState } from "react";
import Modal from "./Modal.jsx";
import Field from "./Field.jsx";
import { validateQuestion } from "../utils/validators.js";
import { optionLetter } from "../utils/format.js";

export default function QuestionFormModal({ initial, categories, defaultCategoryId, onSave, onClose }) {
  const isEdit = Boolean(initial);

  // Form state starts from the question being edited, or from empty values.
  const [form, setForm] = useState(() => ({
    categoryId: initial?.categoryId || defaultCategoryId || categories[0]?.id || "",
    text: initial?.text || "",
    options: initial?.options ? [...initial.options] : ["", "", "", ""],
    correctIndex: Number.isInteger(initial?.correctIndex) ? initial.correctIndex : null,
    topic: initial?.topic || "",
    explanation: initial?.explanation || "",
  }));
  const [errors, setErrors] = useState({});

  const setField = (name, value) => setForm((f) => ({ ...f, [name]: value }));
  const setOption = (index, value) =>
    setForm((f) => ({ ...f, options: f.options.map((o, i) => (i === index ? value : o)) }));

  function handleSubmit(event) {
    event.preventDefault();
    const found = validateQuestion(form, categories);
    setErrors(found);
    if (Object.keys(found).length > 0) return;
    onSave(form);
  }

  const optionErrors = Array.isArray(errors.options) ? errors.options : [];

  return (
    <Modal title={isEdit ? "Edit question" : "Add new question"} onClose={onClose} wide>
      <form onSubmit={handleSubmit} noValidate>
        <Field id="q-category" label="Category" error={errors.categoryId} required>
          <select
            id="q-category"
            value={form.categoryId}
            onChange={(e) => setField("categoryId", e.target.value)}
            aria-invalid={Boolean(errors.categoryId)}
            aria-describedby={errors.categoryId ? "q-category-msg" : undefined}
          >
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </Field>

        <Field id="q-text" label="Question" error={errors.text} hint={`${form.text.trim().length}/300 characters`} required>
          <textarea
            id="q-text"
            rows={3}
            value={form.text}
            onChange={(e) => setField("text", e.target.value)}
            aria-invalid={Boolean(errors.text)}
            aria-describedby="q-text-msg"
          />
        </Field>

        <fieldset className="options-fieldset">
          <legend>
            Answer options <span className="required-mark" aria-hidden="true">*</span>
          </legend>
          <p className="field-hint">Enter four different options, then select the radio button beside the correct one.</p>
          {typeof errors.options === "string" && (
            <p className="field-error" role="alert">
              {errors.options}
            </p>
          )}
          {form.options.map((option, i) => {
            const id = `q-option-${i}`;
            return (
              <div key={id} className={`option-row ${optionErrors[i] ? "has-error" : ""}`}>
                <input
                  type="radio"
                  name="correct"
                  className="correct-radio"
                  checked={form.correctIndex === i}
                  onChange={() => setField("correctIndex", i)}
                  aria-label={`Mark option ${optionLetter(i)} as the correct answer`}
                />
                <div className="option-input">
                  <label htmlFor={id} className="sr-only">
                    Option {optionLetter(i)}
                  </label>
                  <input
                    id={id}
                    type="text"
                    placeholder={`Option ${optionLetter(i)}`}
                    value={option}
                    onChange={(e) => setOption(i, e.target.value)}
                    aria-invalid={Boolean(optionErrors[i])}
                    aria-describedby={optionErrors[i] ? `${id}-msg` : undefined}
                  />
                  {optionErrors[i] && (
                    <p id={`${id}-msg`} className="field-error" role="alert">
                      {optionErrors[i]}
                    </p>
                  )}
                </div>
              </div>
            );
          })}
          {errors.correctIndex && (
            <p className="field-error" role="alert">
              {errors.correctIndex}
            </p>
          )}
        </fieldset>

        <Field id="q-topic" label="Topic (shown as 'needs more practice')" error={errors.topic} required>
          <input
            id="q-topic"
            type="text"
            placeholder="e.g. Flexbox"
            value={form.topic}
            onChange={(e) => setField("topic", e.target.value)}
            aria-invalid={Boolean(errors.topic)}
            aria-describedby={errors.topic ? "q-topic-msg" : undefined}
          />
        </Field>

        <Field
          id="q-explanation"
          label="Explanation (optional)"
          error={errors.explanation}
          hint="Shown to students in the answer review."
        >
          <textarea
            id="q-explanation"
            rows={2}
            value={form.explanation}
            onChange={(e) => setField("explanation", e.target.value)}
            aria-invalid={Boolean(errors.explanation)}
            aria-describedby="q-explanation-msg"
          />
        </Field>

        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary">
            {isEdit ? "Save changes" : "Add question"}
          </button>
        </div>
      </form>
    </Modal>
  );
}
