// Loading indicators.
//  <PageLoader />  - skeleton cards shown while data "loads"
//  <Spinner />     - small spinner for buttons

export function PageLoader({ label = "Loading…" }) {
  return (
    <div role="status" aria-live="polite" className="page-loader">
      <span className="sr-only">{label}</span>
      <div className="skeleton skeleton-title" />
      <div className="grid grid-4">
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className="skeleton skeleton-card" />
        ))}
      </div>
      <div className="skeleton skeleton-block" />
    </div>
  );
}

export function Spinner({ label = "Loading" }) {
  return (
    <span className="spinner" role="status">
      <span className="sr-only">{label}</span>
    </span>
  );
}
