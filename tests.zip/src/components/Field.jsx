// Field - a label + input wrapper that wires up accessibility for you.
// The child control must use the same `id`. Error text is announced to
// screen readers through role="alert".
//
//  <Field id="name" label="Name" error={errors.name} hint="2-30 characters">
//    <input id="name" ... aria-invalid={Boolean(errors.name)} aria-describedby="name-msg" />
//  </Field>
//
// The message paragraph always has the id `${id}-msg` so inputs can point at it.

export default function Field({ id, label, error, hint, children, required = false }) {
  return (
    <div className={`field ${error ? "has-error" : ""}`}>
      <label htmlFor={id}>
        {label}
        {required && (
          <span className="required-mark" aria-hidden="true">
            {" "}*
          </span>
        )}
      </label>
      {children}
      {(error || hint) && (
        <p id={`${id}-msg`} className={error ? "field-error" : "field-hint"} role={error ? "alert" : undefined}>
          {error || hint}
        </p>
      )}
    </div>
  );
}
