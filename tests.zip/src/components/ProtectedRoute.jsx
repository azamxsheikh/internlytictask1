// ProtectedRoute - only lets a signed-in demo admin see the wrapped pages.
// Everyone else is redirected to /admin/login (and sent back afterwards).
// Reminder: this is a front-end convenience, not real security (see AuthContext).

import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

export default function ProtectedRoute({ children }) {
  const { isAdmin } = useAuth();
  const location = useLocation();

  if (!isAdmin) {
    return <Navigate to="/admin/login" replace state={{ from: location.pathname }} />;
  }
  return children;
}
