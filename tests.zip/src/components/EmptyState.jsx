// EmptyState - friendly message shown when a list has nothing to display.

import Icon from "./Icon.jsx";

export default function EmptyState({ icon = "info", title, children, action }) {
  return (
    <div className="empty-state">
      <div className="empty-icon">
        <Icon name={icon} size={28} />
      </div>
      <h3>{title}</h3>
      {children && <p>{children}</p>}
      {action}
    </div>
  );
}
