// ProgressBar - accessible progress bar (screen readers read the value).

export default function ProgressBar({ value, label, tone = "teal", size = "md" }) {
  const clamped = Math.max(0, Math.min(100, value));
  return (
    <div
      className={`progress progress-${size}`}
      role="progressbar"
      aria-label={label}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={Math.round(clamped)}
    >
      <div className={`progress-fill tone-fill-${tone}`} style={{ width: `${clamped}%` }} />
    </div>
  );
}
