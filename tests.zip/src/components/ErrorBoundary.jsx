// ErrorBoundary - catches unexpected rendering errors so the user sees a
// helpful screen instead of a blank page. (React requires a class component
// for this feature.)

import { Component } from "react";
import { clearAllAppData } from "../utils/storage.js";

export default class ErrorBoundary extends Component {
  state = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error, info) {
    console.error("Unexpected application error:", error, info);
  }

  render() {
    if (!this.state.hasError) return this.props.children;
    return (
      <div className="fatal">
        <h1>Something went wrong</h1>
        <p>
          The page hit an unexpected error. Try reloading. If it keeps happening, the saved browser data might be
          damaged - resetting it restores the original demo data (your quiz history will be erased).
        </p>
        <div className="fatal-actions">
          <button type="button" className="btn btn-primary" onClick={() => window.location.reload()}>
            Reload page
          </button>
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() => {
              clearAllAppData();
              window.location.href = "/";
            }}
          >
            Reset app data
          </button>
        </div>
      </div>
    );
  }
}
