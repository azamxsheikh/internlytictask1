// Shell - the page frame shared by the student and admin areas:
// a responsive sidebar (slides in on phones/tablets), a top bar and the page content.
// Pages are rendered through <Outlet /> (React Router's "nested route" slot).

import { useEffect, useState } from "react";
import { NavLink, Outlet, useLocation } from "react-router-dom";
import Icon from "./Icon.jsx";

export default function Shell({ areaLabel, links, topRight, footer }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const { pathname } = useLocation();

  // Close the mobile menu whenever the page changes, and scroll to the top.
  useEffect(() => {
    setMenuOpen(false);
    window.scrollTo(0, 0);
  }, [pathname]);

  // Let the Escape key close the mobile menu.
  useEffect(() => {
    if (!menuOpen) return undefined;
    const onKey = (e) => e.key === "Escape" && setMenuOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [menuOpen]);

  return (
    <div className="shell">
      <a className="skip-link" href="#main">
        Skip to main content
      </a>

      <aside id="sidebar" className={`sidebar ${menuOpen ? "open" : ""}`}>
        <div className="brand">
          <div className="brand-mark">
            <Icon name="check" size={20} />
          </div>
          <div>
            <p className="brand-name">Internlytic</p>
            <p className="brand-sub">Skills Assessment</p>
          </div>
        </div>

        <nav aria-label={`${areaLabel} navigation`}>
          <ul className="nav-list">
            {links.map((link) => (
              <li key={link.to}>
                <NavLink to={link.to} end={link.end} className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`}>
                  <Icon name={link.icon} size={20} />
                  <span>{link.label}</span>
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>

        <div className="sidebar-footer">{footer}</div>
      </aside>

      {menuOpen && <div className="scrim" onClick={() => setMenuOpen(false)} aria-hidden="true" />}

      <div className="shell-body">
        <header className="topbar">
          <button
            type="button"
            className="icon-btn menu-btn"
            aria-label={menuOpen ? "Close navigation menu" : "Open navigation menu"}
            aria-expanded={menuOpen}
            aria-controls="sidebar"
            onClick={() => setMenuOpen((open) => !open)}
          >
            <Icon name={menuOpen ? "x" : "menu"} />
          </button>
          <span className="topbar-area">{areaLabel}</span>
          <div className="topbar-right">{topRight}</div>
        </header>

        <main id="main" className="content" tabIndex={-1}>
          <Outlet />
        </main>
      </div>
    </div>
  );
}
