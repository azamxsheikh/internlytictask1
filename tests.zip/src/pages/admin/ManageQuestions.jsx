// ManageQuestions - admin CRUD for questions:
// list with search + category filter, Add, Edit and Delete (with confirmation).

import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useApp } from "../../context/AppContext.jsx";
import { useToast } from "../../context/ToastContext.jsx";
import { optionLetter } from "../../utils/format.js";
import PageHeader from "../../components/PageHeader.jsx";
import EmptyState from "../../components/EmptyState.jsx";
import ConfirmModal from "../../components/ConfirmModal.jsx";
import QuestionFormModal from "../../components/QuestionFormModal.jsx";
import { PageLoader } from "../../components/Loader.jsx";
import Icon from "../../components/Icon.jsx";

export default function ManageQuestions() {
  const { loading, categories, questions, addQuestion, updateQuestion, deleteQuestion } = useApp();
  const toast = useToast();

  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [formState, setFormState] = useState(null); // null = closed, {question} = open (question null => add)
  const [toDelete, setToDelete] = useState(null);

  const categoryName = useMemo(() => Object.fromEntries(categories.map((c) => [c.id, c.name])), [categories]);

  const visible = useMemo(() => {
    const term = search.trim().toLowerCase();
    return questions
      .filter((q) => categoryFilter === "all" || q.categoryId === categoryFilter)
      .filter(
        (q) =>
          !term ||
          q.text.toLowerCase().includes(term) ||
          q.topic.toLowerCase().includes(term) ||
          q.options.some((o) => o.toLowerCase().includes(term))
      );
  }, [questions, search, categoryFilter]);

  if (loading) return <PageLoader label="Loading questions" />;

  function handleSave(data) {
    if (formState.question) {
      updateQuestion(formState.question.id, data);
      toast.success("Question updated.");
    } else {
      addQuestion(data);
      toast.success("Question added.");
    }
    setFormState(null);
  }

  function handleDelete() {
    deleteQuestion(toDelete.id);
    toast.success("Question deleted.");
    setToDelete(null);
  }

  const noCategories = categories.length === 0;

  return (
    <>
      <PageHeader
        title="Manage questions"
        description={`${questions.length} question${questions.length === 1 ? "" : "s"} across ${categories.length} categor${categories.length === 1 ? "y" : "ies"}.`}
        actions={
          <button
            type="button"
            className="btn btn-primary"
            onClick={() => setFormState({ question: null })}
            disabled={noCategories}
          >
            <Icon name="plus" size={16} /> Add question
          </button>
        }
      />

      {noCategories && (
        <div className="notice notice-warning" role="note">
          <Icon name="alert" size={20} />
          <p>
            You need at least one category before adding questions.{" "}
            <Link to="/admin/categories">Create a category</Link>.
          </p>
        </div>
      )}

      <div className="toolbar card">
        <div className="search-box">
          <label htmlFor="question-search" className="sr-only">
            Search questions
          </label>
          <Icon name="search" size={18} />
          <input
            id="question-search"
            type="search"
            placeholder="Search by question, topic or option…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="toolbar-field">
          <label htmlFor="question-category">Category</label>
          <select id="question-category" value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)}>
            <option value="all">All categories</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {questions.length === 0 ? (
        <div className="card">
          <EmptyState
            icon="list"
            title="No questions yet"
            action={
              !noCategories && (
                <button type="button" className="btn btn-primary" onClick={() => setFormState({ question: null })}>
                  Add the first question
                </button>
              )
            }
          >
            Students will see questions here once you add them.
          </EmptyState>
        </div>
      ) : visible.length === 0 ? (
        <div className="card">
          <EmptyState
            icon="search"
            title="No questions match your search"
            action={
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => {
                  setSearch("");
                  setCategoryFilter("all");
                }}
              >
                Clear search and filters
              </button>
            }
          >
            Try a different keyword or category.
          </EmptyState>
        </div>
      ) : (
        <ul className="question-list">
          {visible.map((q) => (
            <li key={q.id} className="card question-row">
              <div className="question-row-main">
                <div className="question-row-tags">
                  <span className="badge">{categoryName[q.categoryId] || "Unknown category"}</span>
                  <span className="badge badge-outline">{q.topic}</span>
                </div>
                <p className="question-row-text">{q.text}</p>
                <ol className="question-row-options" type="A">
                  {q.options.map((o, i) => (
                    <li key={i} className={i === q.correctIndex ? "is-answer" : ""}>
                      <span className="sr-only">Option {optionLetter(i)}: </span>
                      {o}
                      {i === q.correctIndex && <span className="answer-flag"> (correct)</span>}
                    </li>
                  ))}
                </ol>
              </div>
              <div className="question-row-actions">
                <button
                  type="button"
                  className="btn btn-secondary btn-sm"
                  onClick={() => setFormState({ question: q })}
                  aria-label={`Edit question: ${q.text}`}
                >
                  <Icon name="edit" size={16} /> Edit
                </button>
                <button
                  type="button"
                  className="btn btn-danger-outline btn-sm"
                  onClick={() => setToDelete(q)}
                  aria-label={`Delete question: ${q.text}`}
                >
                  <Icon name="trash" size={16} /> Delete
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}

      {formState && (
        <QuestionFormModal
          initial={formState.question}
          categories={categories}
          defaultCategoryId={categoryFilter !== "all" ? categoryFilter : undefined}
          onSave={handleSave}
          onClose={() => setFormState(null)}
        />
      )}

      {toDelete && (
        <ConfirmModal
          title="Delete this question?"
          confirmLabel="Delete question"
          danger
          onConfirm={handleDelete}
          onCancel={() => setToDelete(null)}
        >
          <p>&ldquo;{toDelete.text}&rdquo;</p>
          <p>This cannot be undone. Past quiz results that included it are not affected.</p>
        </ConfirmModal>
      )}
    </>
  );
}
