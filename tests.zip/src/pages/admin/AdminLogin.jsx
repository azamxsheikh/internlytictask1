// AdminLogin - sign in to the admin panel (DEMO ONLY).
//  * First visit: shows a "create demo admin account" form (no password is hard-coded).
//  * After that: a normal email + password sign-in form.

import { useState } from "react";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext.jsx";
import { useToast } from "../../context/ToastContext.jsx";
import { validateAdminForm } from "../../utils/validators.js";
import Field from "../../components/Field.jsx";
import Icon from "../../components/Icon.jsx";
import { Spinner } from "../../components/Loader.jsx";
import ConfirmModal from "../../components/ConfirmModal.jsx";

export default function AdminLogin() {
  const { hasAccount, isAdmin, createAdmin, login, resetAdminAccount } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();

  const isSetup = !hasAccount;
  const [form, setForm] = useState({ email: "", password: "", confirm: "" });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState("");
  const [busy, setBusy] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  // Already signed in? Skip the form.
  if (isAdmin) return <Navigate to="/admin" replace />;

  const redirectTo = location.state?.from && location.state.from.startsWith("/admin") ? location.state.from : "/admin";
  const setField = (name, value) => setForm((f) => ({ ...f, [name]: value }));

  async function handleSubmit(event) {
    event.preventDefault();
    setFormError("");
    const found = validateAdminForm(form, isSetup);
    setErrors(found);
    if (Object.keys(found).length > 0) return;

    setBusy(true);
    const result = isSetup ? await createAdmin(form.email, form.password) : await login(form.email, form.password);
    setBusy(false);

    if (result.ok) {
      toast.success(isSetup ? "Demo admin account created. You are signed in." : "Welcome back, admin!");
      navigate(redirectTo, { replace: true });
    } else {
      setFormError(result.error);
    }
  }

  return (
    <div className="login-page">
      <div className="login-card card">
        <div className="login-brand">
          <div className="brand-mark brand-mark-lg">
            <Icon name="shield" size={26} />
          </div>
          <h1>{isSetup ? "Create demo admin account" : "Admin sign in"}</h1>
          <p className="muted">
            {isSetup
              ? "No admin exists in this browser yet. Create one to manage questions and categories."
              : "Sign in to manage quiz questions and categories."}
          </p>
        </div>

        <div className="notice notice-warning" role="note">
          <Icon name="alert" size={20} />
          <p>
            <strong>Demo-only authentication.</strong> This login runs entirely in your browser, so it only keeps ordinary
            students out of the admin screens - it is not secure. Production systems must verify credentials and authorise
            every admin action on a secure server.
          </p>
        </div>

        <form onSubmit={handleSubmit} noValidate>
          {formError && (
            <div className="notice notice-error" role="alert">
              <Icon name="alert" size={20} />
              <p>{formError}</p>
            </div>
          )}

          <Field id="admin-email" label="Email address" error={errors.email} required>
            <input
              id="admin-email"
              type="email"
              autoComplete="username"
              value={form.email}
              onChange={(e) => setField("email", e.target.value)}
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? "admin-email-msg" : undefined}
            />
          </Field>

          <Field
            id="admin-password"
            label="Password"
            error={errors.password}
            hint={isSetup ? "At least 8 characters, with a letter and a number." : undefined}
            required
          >
            <input
              id="admin-password"
              type="password"
              autoComplete={isSetup ? "new-password" : "current-password"}
              value={form.password}
              onChange={(e) => setField("password", e.target.value)}
              aria-invalid={Boolean(errors.password)}
              aria-describedby={errors.password || isSetup ? "admin-password-msg" : undefined}
            />
          </Field>

          {isSetup && (
            <Field id="admin-confirm" label="Confirm password" error={errors.confirm} required>
              <input
                id="admin-confirm"
                type="password"
                autoComplete="new-password"
                value={form.confirm}
                onChange={(e) => setField("confirm", e.target.value)}
                aria-invalid={Boolean(errors.confirm)}
                aria-describedby={errors.confirm ? "admin-confirm-msg" : undefined}
              />
            </Field>
          )}

          <button type="submit" className="btn btn-primary btn-block" disabled={busy}>
            {busy ? <Spinner label="Please wait" /> : <Icon name="lock" size={18} />}
            {isSetup ? "Create account and sign in" : "Sign in"}
          </button>
        </form>

        <div className="login-links">
          <Link to="/" className="link-arrow">
            <Icon name="arrowLeft" size={16} /> Back to student site
          </Link>
          {!isSetup && (
            <button type="button" className="link-button" onClick={() => setConfirmReset(true)}>
              Forgot password? Reset demo account
            </button>
          )}
        </div>
      </div>

      {confirmReset && (
        <ConfirmModal
          title="Reset the demo admin account?"
          confirmLabel="Reset account"
          danger
          onConfirm={() => {
            resetAdminAccount();
            setConfirmReset(false);
            setForm({ email: "", password: "", confirm: "" });
            toast.info("The demo admin account was removed. Create a new one.");
          }}
          onCancel={() => setConfirmReset(false)}
        >
          <p>
            This removes the saved demo admin login from this browser so you can create a new one. Quiz questions and
            student history are not affected.
          </p>
          <p className="small muted">
            (This button exists only because the login is a demo. A real system would use a secure password-reset flow.)
          </p>
        </ConfirmModal>
      )}
    </div>
  );
}
