// AdminDashboard - overview numbers and quick actions for administrators.

import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useApp } from "../../context/AppContext.jsx";
import { useToast } from "../../context/ToastContext.jsx";
import PageHeader from "../../components/PageHeader.jsx";
import StatCard from "../../components/StatCard.jsx";
import ProgressBar from "../../components/ProgressBar.jsx";
import EmptyState from "../../components/EmptyState.jsx";
import ConfirmModal from "../../components/ConfirmModal.jsx";
import { PageLoader } from "../../components/Loader.jsx";
import Icon from "../../components/Icon.jsx";

const RECOMMENDED_MINIMUM = 10;

export default function AdminDashboard() {
  const { loading, categories, questions, attempts, resetDemoData } = useApp();
  const toast = useToast();
  const [confirmReset, setConfirmReset] = useState(false);

  const counts = useMemo(() => {
    const map = {};
    questions.forEach((q) => {
      map[q.categoryId] = (map[q.categoryId] || 0) + 1;
    });
    return map;
  }, [questions]);

  if (loading) return <PageLoader label="Loading admin overview" />;

  const largest = Math.max(1, ...categories.map((c) => counts[c.id] || 0));
  const needMore = categories.filter((c) => (counts[c.id] || 0) < RECOMMENDED_MINIMUM);

  return (
    <>
      <PageHeader
        title="Admin overview"
        description="Manage the quiz content that students see."
        actions={
          <Link to="/admin/questions" className="btn btn-primary">
            <Icon name="plus" size={16} /> Add question
          </Link>
        }
      />

      <div className="notice notice-warning" role="note">
        <Icon name="alert" size={20} />
        <p>
          <strong>Demo mode:</strong> questions, categories and student attempts are stored in this browser&apos;s Local
          Storage, and the admin login is demo-only. See the README for what a production system needs.
        </p>
      </div>

      <section className="section" aria-labelledby="admin-stats">
        <h2 id="admin-stats" className="sr-only">
          Totals
        </h2>
        <div className="grid grid-4">
          <StatCard icon="list" label="Total questions" value={questions.length} tone="navy" />
          <StatCard icon="layers" label="Quiz categories" value={categories.length} tone="teal" />
          <StatCard icon="history" label="Attempts in this browser" value={attempts.length} tone="gold" />
          <StatCard
            icon="alert"
            label="Categories below 10 questions"
            value={needMore.length}
            hint={needMore.length ? "Add more questions" : "All good"}
            tone={needMore.length ? "red" : "green"}
          />
        </div>
      </section>

      <div className="grid grid-2 section">
        <section className="card" aria-labelledby="per-category">
          <div className="section-head">
            <h2 id="per-category">Questions per category</h2>
            <Link to="/admin/categories" className="link-arrow">
              Manage <Icon name="arrowRight" size={16} />
            </Link>
          </div>
          {categories.length === 0 ? (
            <EmptyState
              icon="layers"
              title="No categories yet"
              action={
                <Link to="/admin/categories" className="btn btn-primary">
                  Add a category
                </Link>
              }
            />
          ) : (
            <ul className="progress-list">
              {categories.map((c) => {
                const n = counts[c.id] || 0;
                return (
                  <li key={c.id}>
                    <div className="progress-row">
                      <span>{c.name}</span>
                      <span className="small muted">
                        {n} question{n === 1 ? "" : "s"}
                        {n < RECOMMENDED_MINIMUM && " - add more"}
                      </span>
                    </div>
                    <ProgressBar value={(n / largest) * 100} label={`${c.name}: ${n} questions`} tone={n < RECOMMENDED_MINIMUM ? "gold" : "teal"} />
                  </li>
                );
              })}
            </ul>
          )}
        </section>

        <section className="card" aria-labelledby="quick-actions">
          <h2 id="quick-actions">Quick actions</h2>
          <ul className="action-list">
            <li>
              <Link to="/admin/questions" className="action-item">
                <Icon name="plus" /> <span>Add or edit questions</span>
              </Link>
            </li>
            <li>
              <Link to="/admin/categories" className="action-item">
                <Icon name="layers" /> <span>Manage categories</span>
              </Link>
            </li>
            <li>
              <button type="button" className="action-item" onClick={() => setConfirmReset(true)}>
                <Icon name="refresh" /> <span>Reset demo questions and categories</span>
              </button>
            </li>
          </ul>
        </section>
      </div>

      {confirmReset && (
        <ConfirmModal
          title="Reset demo data?"
          confirmLabel="Yes, reset"
          danger
          onConfirm={() => {
            resetDemoData();
            setConfirmReset(false);
            toast.success("Original demo categories and questions restored.");
          }}
          onCancel={() => setConfirmReset(false)}
        >
          <p>
            All categories and questions will be replaced with the original 4 categories and 40 sample questions. Any
            questions you added or edited will be lost. Student attempt history is kept.
          </p>
        </ConfirmModal>
      )}
    </>
  );
}
