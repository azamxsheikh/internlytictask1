// ManageCategories - admin CRUD for quiz categories.
// Deleting a category also deletes its questions, so the admin is warned first.

import { useMemo, useState } from "react";
import { useApp } from "../../context/AppContext.jsx";
import { useToast } from "../../context/ToastContext.jsx";
import PageHeader from "../../components/PageHeader.jsx";
import EmptyState from "../../components/EmptyState.jsx";
import ConfirmModal from "../../components/ConfirmModal.jsx";
import CategoryFormModal from "../../components/CategoryFormModal.jsx";
import { PageLoader } from "../../components/Loader.jsx";
import Icon from "../../components/Icon.jsx";

export default function ManageCategories() {
  const { loading, categories, questions, addCategory, updateCategory, deleteCategory } = useApp();
  const toast = useToast();

  const [search, setSearch] = useState("");
  const [formState, setFormState] = useState(null); // null = closed, {category} = open (category null => add)
  const [toDelete, setToDelete] = useState(null);

  const counts = useMemo(() => {
    const map = {};
    questions.forEach((q) => {
      map[q.categoryId] = (map[q.categoryId] || 0) + 1;
    });
    return map;
  }, [questions]);

  const visible = useMemo(() => {
    const term = search.trim().toLowerCase();
    return categories.filter(
      (c) => !term || c.name.toLowerCase().includes(term) || c.description.toLowerCase().includes(term)
    );
  }, [categories, search]);

  if (loading) return <PageLoader label="Loading categories" />;

  function handleSave(data) {
    if (formState.category) {
      updateCategory(formState.category.id, data);
      toast.success("Category updated.");
    } else {
      addCategory(data);
      toast.success("Category added.");
    }
    setFormState(null);
  }

  function handleDelete() {
    const removedQuestions = counts[toDelete.id] || 0;
    deleteCategory(toDelete.id);
    toast.success(
      `Category deleted${removedQuestions ? ` along with ${removedQuestions} question${removedQuestions === 1 ? "" : "s"}` : ""}.`
    );
    setToDelete(null);
  }

  return (
    <>
      <PageHeader
        title="Manage categories"
        description="Create, rename or remove the quiz categories students can choose from."
        actions={
          <button type="button" className="btn btn-primary" onClick={() => setFormState({ category: null })}>
            <Icon name="plus" size={16} /> Add category
          </button>
        }
      />

      <div className="toolbar card">
        <div className="search-box">
          <label htmlFor="category-search" className="sr-only">
            Search categories
          </label>
          <Icon name="search" size={18} />
          <input
            id="category-search"
            type="search"
            placeholder="Search categories…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      {categories.length === 0 ? (
        <div className="card">
          <EmptyState
            icon="layers"
            title="No categories yet"
            action={
              <button type="button" className="btn btn-primary" onClick={() => setFormState({ category: null })}>
                Add the first category
              </button>
            }
          >
            Create a category, then add questions to it.
          </EmptyState>
        </div>
      ) : visible.length === 0 ? (
        <div className="card">
          <EmptyState
            icon="search"
            title="No categories match your search"
            action={
              <button type="button" className="btn btn-secondary" onClick={() => setSearch("")}>
                Clear search
              </button>
            }
          />
        </div>
      ) : (
        <div className="grid grid-3">
          {visible.map((c) => {
            const n = counts[c.id] || 0;
            return (
              <article key={c.id} className="card category-card">
                <div className="category-top">
                  <div className="category-icon">
                    <Icon name={c.icon} size={24} />
                  </div>
                  <span className="badge">
                    {n} question{n === 1 ? "" : "s"}
                  </span>
                </div>
                <h3>{c.name}</h3>
                <p className="muted">{c.description}</p>
                <div className="category-footer">
                  <button
                    type="button"
                    className="btn btn-secondary btn-sm"
                    onClick={() => setFormState({ category: c })}
                    aria-label={`Edit category ${c.name}`}
                  >
                    <Icon name="edit" size={16} /> Edit
                  </button>
                  <button
                    type="button"
                    className="btn btn-danger-outline btn-sm"
                    onClick={() => setToDelete(c)}
                    aria-label={`Delete category ${c.name}`}
                  >
                    <Icon name="trash" size={16} /> Delete
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      )}

      {formState && (
        <CategoryFormModal
          initial={formState.category}
          categories={categories}
          onSave={handleSave}
          onClose={() => setFormState(null)}
        />
      )}

      {toDelete && (
        <ConfirmModal
          title={`Delete the ${toDelete.name} category?`}
          confirmLabel="Delete category"
          danger
          onConfirm={handleDelete}
          onCancel={() => setToDelete(null)}
        >
          {(counts[toDelete.id] || 0) > 0 ? (
            <p className="warning-text">
              <Icon name="alert" size={16} /> This will also permanently delete its {counts[toDelete.id]} question
              {counts[toDelete.id] === 1 ? "" : "s"}.
            </p>
          ) : (
            <p>This category has no questions.</p>
          )}
          <p>Students&apos; past results for this category stay in their history.</p>
        </ConfirmModal>
      )}
    </>
  );
}
