// NotFound - shown for any URL that doesn't match a route (404).

import { Link } from "react-router-dom";
import EmptyState from "../components/EmptyState.jsx";

export default function NotFound() {
  return (
    <div className="standalone">
      <EmptyState
        icon="alert"
        title="Page not found"
        action={
          <Link to="/" className="btn btn-primary">
            Go to dashboard
          </Link>
        }
      >
        The page you are looking for does not exist or has been moved.
      </EmptyState>
    </div>
  );
}
