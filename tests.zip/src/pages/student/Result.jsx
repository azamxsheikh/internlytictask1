// Result - the result dashboard shown after submitting a quiz:
// score summary, performance text, topics to practise and a full answer review.
// It reads the saved attempt by id, so it also works when opened from History.

import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useApp } from "../../context/AppContext.jsx";
import { getPerformanceSummary, topicsToPractice, PASS_PERCENTAGE } from "../../utils/scoring.js";
import { formatDate, formatPercent, optionLetter } from "../../utils/format.js";
import EmptyState from "../../components/EmptyState.jsx";
import { PageLoader } from "../../components/Loader.jsx";
import Icon from "../../components/Icon.jsx";

export default function Result() {
  const { attemptId } = useParams();
  const { loading, attempts, categories } = useApp();
  const [reviewFilter, setReviewFilter] = useState("all");

  if (loading) return <PageLoader label="Loading your result" />;

  const attempt = attempts.find((a) => a.id === attemptId);
  if (!attempt) {
    return (
      <div className="card">
        <EmptyState
          icon="alert"
          title="Result not found"
          action={
            <Link to="/history" className="btn btn-primary">
              Go to attempt history
            </Link>
          }
        >
          This attempt does not exist. It may have been cleared, or it was saved in a different browser.
        </EmptyState>
      </div>
    );
  }

  const summary = getPerformanceSummary(attempt.percentage);
  const weakTopics = topicsToPractice(attempt.review);
  const categoryStillExists = categories.some((c) => c.id === attempt.categoryId);

  const shown = attempt.review
    .map((item, index) => ({ item, number: index + 1 }))
    .filter(({ item }) => {
      if (reviewFilter === "correct") return item.isCorrect;
      if (reviewFilter === "incorrect") return !item.isCorrect;
      return true;
    });

  return (
    <>
      <div className="page-header">
        <div>
          <p className="eyebrow">{attempt.categoryName} quiz result</p>
          <h1>{attempt.passed ? "Congratulations, you passed!" : "You did not pass this time"}</h1>
          <p className="muted">Attempted on {formatDate(attempt.date)}</p>
        </div>
        <div className="page-actions">
          {categoryStillExists && (
            <Link to={`/quiz/${attempt.categoryId}`} className="btn btn-primary">
              <Icon name="refresh" size={16} /> Retake quiz
            </Link>
          )}
          <Link to="/" className="btn btn-secondary">
            Dashboard
          </Link>
        </div>
      </div>

      {/* Score summary */}
      <section className="card result-card" aria-labelledby="score-heading">
        <h2 id="score-heading" className="sr-only">
          Score summary
        </h2>
        <div
          className={`score-ring ${attempt.passed ? "ring-pass" : "ring-fail"}`}
          style={{ "--pct": attempt.percentage }}
          role="img"
          aria-label={`Score ${formatPercent(attempt.percentage)}`}
        >
          <div className="score-ring-inner">
            <strong>{formatPercent(attempt.percentage)}</strong>
            <span className={`pill ${attempt.passed ? "pill-pass" : "pill-fail"}`}>{attempt.passed ? "PASS" : "FAIL"}</span>
          </div>
        </div>

        <dl className="result-stats">
          <div>
            <dt>Total questions</dt>
            <dd>{attempt.total}</dd>
          </div>
          <div>
            <dt>Correct answers</dt>
            <dd className="text-success">{attempt.correct}</dd>
          </div>
          <div>
            <dt>Incorrect answers</dt>
            <dd className="text-danger">{attempt.incorrect}</dd>
          </div>
          <div>
            <dt>Obtained marks</dt>
            <dd>
              {attempt.marks} / {attempt.totalMarks}
            </dd>
          </div>
          <div>
            <dt>Percentage</dt>
            <dd>{formatPercent(attempt.percentage)}</dd>
          </div>
          <div>
            <dt>Status</dt>
            <dd className={attempt.passed ? "text-success" : "text-danger"}>{attempt.passed ? "Pass" : "Fail"}</dd>
          </div>
        </dl>
      </section>

      <div className="grid grid-2 section">
        <section className="card" aria-labelledby="summary-heading">
          <h2 id="summary-heading">Performance summary</h2>
          <p className="summary-level">{summary.level}</p>
          <p>{summary.message}</p>
          <p className="small muted">
            Pass mark: {PASS_PERCENTAGE}%. {attempt.unanswered > 0 && `${attempt.unanswered} question(s) were left unanswered.`}
          </p>
        </section>

        <section className="card" aria-labelledby="practice-heading">
          <h2 id="practice-heading">Topics needing more practice</h2>
          {weakTopics.length === 0 ? (
            <EmptyState icon="award" title="No weak topics">
              You answered every question correctly. Great job!
            </EmptyState>
          ) : (
            <ul className="topic-list">
              {weakTopics.map((t) => (
                <li key={t.topic}>
                  <span>{t.topic}</span>
                  <span className="pill pill-fail">
                    {t.wrong} of {t.total} missed
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      {/* Detailed review */}
      <section className="section" aria-labelledby="review-heading">
        <div className="section-head">
          <h2 id="review-heading">Detailed answer review</h2>
          <div className="toolbar-field">
            <label htmlFor="review-filter">Show</label>
            <select id="review-filter" value={reviewFilter} onChange={(e) => setReviewFilter(e.target.value)}>
              <option value="all">All questions ({attempt.review.length})</option>
              <option value="incorrect">Incorrect only ({attempt.incorrect})</option>
              <option value="correct">Correct only ({attempt.correct})</option>
            </select>
          </div>
        </div>

        {shown.length === 0 ? (
          <div className="card">
            <EmptyState icon="search" title="Nothing to show for this filter" />
          </div>
        ) : (
          <ol className="review-list">
            {shown.map(({ item, number }) => (
              <li key={item.questionId} className={`card review-item ${item.isCorrect ? "is-correct" : "is-incorrect"}`}>
                <div className="review-head">
                  <span className="small muted">Question {number}</span>
                  <span className={`pill ${item.isCorrect ? "pill-pass" : "pill-fail"}`}>
                    <Icon name={item.isCorrect ? "check" : "x"} size={14} /> {item.isCorrect ? "Correct" : "Incorrect"}
                  </span>
                </div>
                <h3 className="review-question">{item.text}</h3>

                <ul className="review-options">
                  {item.options.map((option, i) => {
                    const isSelected = item.selectedIndex === i;
                    const isRight = item.correctIndex === i;
                    let state = "";
                    if (isRight) state = "right";
                    else if (isSelected) state = "wrong";
                    return (
                      <li key={i} className={`review-option ${state}`}>
                        <span className="option-letter" aria-hidden="true">
                          {optionLetter(i)}
                        </span>
                        <span className="option-text">{option}</span>
                        {isRight && <span className="review-tag tag-right">Correct answer</span>}
                        {isSelected && <span className={`review-tag ${isRight ? "tag-right" : "tag-wrong"}`}>Your answer</span>}
                      </li>
                    );
                  })}
                </ul>

                <p className="review-summary">
                  <strong>Your answer:</strong>{" "}
                  {item.selectedIndex === null ? (
                    <em>Not answered</em>
                  ) : (
                    `${optionLetter(item.selectedIndex)}. ${item.options[item.selectedIndex]}`
                  )}
                  <br />
                  <strong>Correct answer:</strong> {optionLetter(item.correctIndex)}. {item.options[item.correctIndex]}
                </p>
                {!item.isCorrect && (
                  <p className="practice-note">
                    <Icon name="book" size={16} /> Practise more: <strong>{item.topic}</strong>
                  </p>
                )}
                {item.explanation && <p className="explanation small">{item.explanation}</p>}
              </li>
            ))}
          </ol>
        )}
      </section>
    </>
  );
}
