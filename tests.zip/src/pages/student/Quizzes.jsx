// Quizzes - browse all categories with search, filter and sort.

import { useMemo, useState } from "react";
import { useApp } from "../../context/AppContext.jsx";
import { bestByCategory } from "../../utils/scoring.js";
import PageHeader from "../../components/PageHeader.jsx";
import CategoryCard from "../../components/CategoryCard.jsx";
import EmptyState from "../../components/EmptyState.jsx";
import { PageLoader } from "../../components/Loader.jsx";
import Icon from "../../components/Icon.jsx";

export default function Quizzes() {
  const { loading, categories, questions, attempts } = useApp();
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [sort, setSort] = useState("name");

  const best = useMemo(() => bestByCategory(attempts), [attempts]);
  const counts = useMemo(() => {
    const map = {};
    questions.forEach((q) => {
      map[q.categoryId] = (map[q.categoryId] || 0) + 1;
    });
    return map;
  }, [questions]);

  const visible = useMemo(() => {
    const term = search.trim().toLowerCase();
    return categories
      .filter((c) => !term || c.name.toLowerCase().includes(term) || c.description.toLowerCase().includes(term))
      .filter((c) => {
        if (filter === "attempted") return best[c.id] !== undefined;
        if (filter === "new") return best[c.id] === undefined;
        return true;
      })
      .sort((a, b) =>
        sort === "questions" ? (counts[b.id] || 0) - (counts[a.id] || 0) : a.name.localeCompare(b.name)
      );
  }, [categories, search, filter, sort, best, counts]);

  if (loading) return <PageLoader label="Loading quizzes" />;

  function resetFilters() {
    setSearch("");
    setFilter("all");
    setSort("name");
  }

  return (
    <>
      <PageHeader
        title="Take a quiz"
        description="Pick a category. Each quiz is multiple choice with four options per question. You need 60% to pass."
      />

      <div className="toolbar card">
        <div className="search-box">
          <label htmlFor="quiz-search" className="sr-only">
            Search categories
          </label>
          <Icon name="search" size={18} />
          <input
            id="quiz-search"
            type="search"
            placeholder="Search categories…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="toolbar-field">
          <label htmlFor="quiz-filter">Show</label>
          <select id="quiz-filter" value={filter} onChange={(e) => setFilter(e.target.value)}>
            <option value="all">All categories</option>
            <option value="attempted">Attempted</option>
            <option value="new">Not attempted</option>
          </select>
        </div>
        <div className="toolbar-field">
          <label htmlFor="quiz-sort">Sort by</label>
          <select id="quiz-sort" value={sort} onChange={(e) => setSort(e.target.value)}>
            <option value="name">Name (A–Z)</option>
            <option value="questions">Most questions</option>
          </select>
        </div>
      </div>

      {categories.length === 0 ? (
        <div className="card">
          <EmptyState icon="layers" title="No quiz categories yet">
            An administrator has not created any categories. Please check back later.
          </EmptyState>
        </div>
      ) : visible.length === 0 ? (
        <div className="card">
          <EmptyState
            icon="search"
            title="No categories match your search"
            action={
              <button type="button" className="btn btn-secondary" onClick={resetFilters}>
                Clear search and filters
              </button>
            }
          >
            Try a different keyword or filter.
          </EmptyState>
        </div>
      ) : (
        <div className="grid grid-4">
          {visible.map((c) => (
            <CategoryCard key={c.id} category={c} questionCount={counts[c.id] || 0} bestScore={best[c.id]} />
          ))}
        </div>
      )}
    </>
  );
}
