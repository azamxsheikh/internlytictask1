// History - every saved quiz attempt, with filters, sorting and a mini trend chart.

import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useApp } from "../../context/AppContext.jsx";
import { useToast } from "../../context/ToastContext.jsx";
import { computeStats } from "../../utils/scoring.js";
import { formatDate, formatPercent } from "../../utils/format.js";
import PageHeader from "../../components/PageHeader.jsx";
import EmptyState from "../../components/EmptyState.jsx";
import ConfirmModal from "../../components/ConfirmModal.jsx";
import { PageLoader } from "../../components/Loader.jsx";
import Icon from "../../components/Icon.jsx";

export default function History() {
  const { loading, attempts, clearHistory } = useApp();
  const toast = useToast();
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sort, setSort] = useState("newest");
  const [confirmClear, setConfirmClear] = useState(false);

  // Category names come from the attempts themselves so deleted categories still show up.
  const categoryOptions = useMemo(() => {
    const map = new Map();
    attempts.forEach((a) => map.set(a.categoryId, a.categoryName));
    return [...map.entries()].map(([id, name]) => ({ id, name }));
  }, [attempts]);

  const visible = useMemo(() => {
    const list = attempts
      .filter((a) => categoryFilter === "all" || a.categoryId === categoryFilter)
      .filter((a) => statusFilter === "all" || (statusFilter === "passed" ? a.passed : !a.passed));
    const sorters = {
      newest: (a, b) => new Date(b.date) - new Date(a.date),
      oldest: (a, b) => new Date(a.date) - new Date(b.date),
      highest: (a, b) => b.percentage - a.percentage,
      lowest: (a, b) => a.percentage - b.percentage,
    };
    return [...list].sort(sorters[sort]);
  }, [attempts, categoryFilter, statusFilter, sort]);

  const stats = useMemo(() => computeStats(visible), [visible]);

  // Oldest -> newest for the trend chart (last 10 of the filtered attempts).
  const trend = useMemo(
    () => [...visible].sort((a, b) => new Date(a.date) - new Date(b.date)).slice(-10),
    [visible]
  );

  if (loading) return <PageLoader label="Loading history" />;

  function resetFilters() {
    setCategoryFilter("all");
    setStatusFilter("all");
    setSort("newest");
  }

  return (
    <>
      <PageHeader
        title="Attempt history"
        description="Review your previous quiz attempts and track how your scores change over time."
        actions={
          attempts.length > 0 && (
            <button type="button" className="btn btn-secondary" onClick={() => setConfirmClear(true)}>
              <Icon name="trash" size={16} /> Clear history
            </button>
          )
        }
      />

      <div className="notice notice-info" role="note">
        <Icon name="info" size={20} />
        <p>
          <strong>Storage note:</strong> your history is saved in this browser&apos;s Local Storage. It stays on this
          device only, and is lost if you clear your browser data, use a private window or switch browsers. A production
          version would save it to a database.
        </p>
      </div>

      {attempts.length === 0 ? (
        <div className="card">
          <EmptyState
            icon="history"
            title="No attempts yet"
            action={
              <Link to="/quizzes" className="btn btn-primary">
                Take your first quiz
              </Link>
            }
          >
            When you finish a quiz it will be listed here with your score and date.
          </EmptyState>
        </div>
      ) : (
        <>
          <div className="toolbar card">
            <div className="toolbar-field">
              <label htmlFor="h-category">Category</label>
              <select id="h-category" value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)}>
                <option value="all">All categories</option>
                {categoryOptions.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="toolbar-field">
              <label htmlFor="h-status">Status</label>
              <select id="h-status" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
                <option value="all">Passed and failed</option>
                <option value="passed">Passed only</option>
                <option value="failed">Failed only</option>
              </select>
            </div>
            <div className="toolbar-field">
              <label htmlFor="h-sort">Sort by</label>
              <select id="h-sort" value={sort} onChange={(e) => setSort(e.target.value)}>
                <option value="newest">Newest first</option>
                <option value="oldest">Oldest first</option>
                <option value="highest">Highest score</option>
                <option value="lowest">Lowest score</option>
              </select>
            </div>
          </div>

          {visible.length === 0 ? (
            <div className="card">
              <EmptyState
                icon="search"
                title="No attempts match these filters"
                action={
                  <button type="button" className="btn btn-secondary" onClick={resetFilters}>
                    Reset filters
                  </button>
                }
              />
            </div>
          ) : (
            <>
              <div className="grid grid-2 section">
                <section className="card" aria-labelledby="trend-heading">
                  <h2 id="trend-heading">Performance trend</h2>
                  <p className="small muted">Scores of your last {trend.length} attempt{trend.length === 1 ? "" : "s"} (oldest to newest).</p>
                  <div className="trend" role="img" aria-label={`Bar chart of ${trend.length} recent scores`}>
                    {trend.map((a) => (
                      <div key={a.id} className="trend-col" title={`${a.categoryName}: ${formatPercent(a.percentage)}`}>
                        <span className="trend-value">{Math.round(a.percentage)}</span>
                        <div className="trend-bar-wrap">
                          <div
                            className={`trend-bar ${a.passed ? "bar-pass" : "bar-fail"}`}
                            style={{ height: `${Math.max(a.percentage, 4)}%` }}
                          />
                        </div>
                        <span className="trend-label">{a.categoryName.slice(0, 4)}</span>
                      </div>
                    ))}
                  </div>
                </section>

                <section className="card" aria-labelledby="summary-h-heading">
                  <h2 id="summary-h-heading">Summary of shown attempts</h2>
                  <dl className="mini-stats">
                    <div>
                      <dt>Attempts</dt>
                      <dd>{stats.total}</dd>
                    </div>
                    <div>
                      <dt>Average</dt>
                      <dd>{formatPercent(stats.average)}</dd>
                    </div>
                    <div>
                      <dt>Best</dt>
                      <dd>{formatPercent(stats.best)}</dd>
                    </div>
                    <div>
                      <dt>Passed</dt>
                      <dd>{stats.passed}</dd>
                    </div>
                  </dl>
                </section>
              </div>

              <div className="card table-card">
                <table className="table">
                  <caption className="sr-only">Quiz attempts</caption>
                  <thead>
                    <tr>
                      <th scope="col">Category</th>
                      <th scope="col">Date</th>
                      <th scope="col">Score</th>
                      <th scope="col">Percentage</th>
                      <th scope="col">Status</th>
                      <th scope="col">
                        <span className="sr-only">Actions</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {visible.map((a) => (
                      <tr key={a.id}>
                        <td data-label="Category">
                          <strong>{a.categoryName}</strong>
                        </td>
                        <td data-label="Date">{formatDate(a.date)}</td>
                        <td data-label="Score">
                          {a.marks} / {a.totalMarks}
                        </td>
                        <td data-label="Percentage">{formatPercent(a.percentage)}</td>
                        <td data-label="Status">
                          <span className={`pill ${a.passed ? "pill-pass" : "pill-fail"}`}>{a.passed ? "Pass" : "Fail"}</span>
                        </td>
                        <td data-label="Details" className="cell-actions">
                          <Link
                            to={`/result/${a.id}`}
                            className="btn btn-secondary btn-sm"
                            aria-label={`View ${a.categoryName} result from ${formatDate(a.date)}`}
                          >
                            View
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </>
      )}

      {confirmClear && (
        <ConfirmModal
          title="Clear all attempt history?"
          confirmLabel="Yes, clear history"
          danger
          onConfirm={() => {
            clearHistory();
            setConfirmClear(false);
            toast.success("Your attempt history has been cleared.");
          }}
          onCancel={() => setConfirmClear(false)}
        >
          <p>This permanently deletes all {attempts.length} saved attempts from this browser. It cannot be undone.</p>
        </ConfirmModal>
      )}
    </>
  );
}
