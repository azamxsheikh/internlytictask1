// Quiz - the examination screen.
//
// Two components:
//   <Quiz />         finds the category and its questions (handles loading / not found / empty)
//   <QuizSession />  runs the actual exam: one question at a time, navigation, progress,
//                    confirmation before submit, scoring and saving the attempt.
//
// The questions are copied ("snapshotted") when the quiz starts, so if an admin
// edits a question in another tab, the quiz you are taking does not change halfway.

import { useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useApp } from "../../context/AppContext.jsx";
import { useToast } from "../../context/ToastContext.jsx";
import { scoreQuiz } from "../../utils/scoring.js";
import { createId } from "../../utils/storage.js";
import { optionLetter } from "../../utils/format.js";
import ProgressBar from "../../components/ProgressBar.jsx";
import ConfirmModal from "../../components/ConfirmModal.jsx";
import EmptyState from "../../components/EmptyState.jsx";
import { PageLoader } from "../../components/Loader.jsx";
import Icon from "../../components/Icon.jsx";

export default function Quiz() {
  const { categoryId } = useParams();
  const { loading, categories, questions } = useApp();

  if (loading) return <PageLoader label="Preparing your quiz" />;

  const category = categories.find((c) => c.id === categoryId);
  if (!category) {
    return (
      <div className="card">
        <EmptyState
          icon="alert"
          title="Quiz not found"
          action={
            <Link to="/quizzes" className="btn btn-primary">
              Browse quizzes
            </Link>
          }
        >
          This category does not exist. It may have been removed by an administrator.
        </EmptyState>
      </div>
    );
  }

  const categoryQuestions = questions.filter((q) => q.categoryId === category.id);
  if (categoryQuestions.length === 0) {
    return (
      <div className="card">
        <EmptyState
          icon="list"
          title={`No questions in ${category.name} yet`}
          action={
            <Link to="/quizzes" className="btn btn-primary">
              Choose another quiz
            </Link>
          }
        >
          Questions have not been added to this category.
        </EmptyState>
      </div>
    );
  }

  // `key` makes React start a brand-new session if the category in the URL changes.
  return <QuizSession key={category.id} category={category} quizQuestions={categoryQuestions} />;
}

function QuizSession({ category, quizQuestions }) {
  const navigate = useNavigate();
  const toast = useToast();
  const { saveAttempt } = useApp();

  // Snapshot of the questions for the whole attempt.
  const [snapshot] = useState(quizQuestions);
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState({}); // { questionId: selectedOptionIndex }
  const [confirmSubmit, setConfirmSubmit] = useState(false);
  const [confirmExit, setConfirmExit] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const total = snapshot.length;
  const question = snapshot[current];
  const answeredCount = useMemo(() => snapshot.filter((q) => Number.isInteger(answers[q.id])).length, [snapshot, answers]);
  const unanswered = total - answeredCount;
  const isLast = current === total - 1;

  function selectOption(index) {
    setAnswers((prev) => ({ ...prev, [question.id]: index }));
  }

  function submit() {
    if (submitting) return;
    setSubmitting(true);
    try {
      const result = scoreQuiz(snapshot, answers);
      const attempt = {
        id: createId("attempt"),
        categoryId: category.id,
        categoryName: category.name,
        date: new Date().toISOString(),
        total: result.total,
        correct: result.correct,
        incorrect: result.incorrect,
        unanswered: result.unanswered,
        marks: result.marks,
        totalMarks: result.totalMarks,
        percentage: result.percentage,
        passed: result.passed,
        review: result.review, // full copy so history stays correct even if questions are edited later
      };
      saveAttempt(attempt);
      toast.success("Quiz submitted! Here are your results.");
      navigate(`/result/${attempt.id}`, { replace: true });
    } catch (err) {
      console.error(err);
      setSubmitting(false);
      setConfirmSubmit(false);
      toast.error("Something went wrong while submitting your quiz. Please try again.");
    }
  }

  return (
    <div className="quiz">
      <div className="quiz-header">
        <div>
          <p className="eyebrow">{category.name} quiz</p>
          <h1 className="quiz-title">
            Question {current + 1} <span className="muted">of {total}</span>
          </h1>
        </div>
        <button type="button" className="btn btn-secondary btn-sm" onClick={() => setConfirmExit(true)}>
          <Icon name="x" size={16} /> Exit quiz
        </button>
      </div>

      <div className="quiz-progress">
        <div className="progress-row">
          <span className="small">Progress</span>
          <span className="small muted">
            {answeredCount} of {total} answered
          </span>
        </div>
        <ProgressBar value={(answeredCount / total) * 100} label="Quiz progress: questions answered" />
      </div>

      <div className="quiz-layout">
        <section className="card question-card" aria-labelledby="question-text">
          <p className="topic-tag">{question.topic}</p>
          <h2 id="question-text" className="question-text">
            {question.text}
          </h2>

          {/* Native radio buttons: keyboard and screen-reader friendly */}
          <fieldset className="options">
            <legend className="sr-only">Choose one answer</legend>
            {question.options.map((option, i) => {
              const selected = answers[question.id] === i;
              const id = `option-${question.id}-${i}`;
              return (
                <label key={id} htmlFor={id} className={`option ${selected ? "selected" : ""}`}>
                  <input
                    id={id}
                    type="radio"
                    name={`question-${question.id}`}
                    checked={selected}
                    onChange={() => selectOption(i)}
                    className="sr-only"
                  />
                  <span className="option-letter" aria-hidden="true">
                    {optionLetter(i)}
                  </span>
                  <span className="option-text">{option}</span>
                  {selected && <Icon name="check" size={20} className="option-check" />}
                </label>
              );
            })}
          </fieldset>

          <div className="quiz-nav">
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => setCurrent((c) => c - 1)}
              disabled={current === 0}
            >
              <Icon name="arrowLeft" size={18} /> Previous
            </button>
            {isLast ? (
              <button type="button" className="btn btn-accent" onClick={() => setConfirmSubmit(true)}>
                Submit quiz <Icon name="check" size={18} />
              </button>
            ) : (
              <button type="button" className="btn btn-primary" onClick={() => setCurrent((c) => c + 1)}>
                Next <Icon name="arrowRight" size={18} />
              </button>
            )}
          </div>
        </section>

        <aside className="card navigator" aria-labelledby="navigator-heading">
          <h2 id="navigator-heading" className="navigator-title">
            Question navigator
          </h2>
          <ol className="navigator-grid">
            {snapshot.map((q, i) => {
              const isAnswered = Number.isInteger(answers[q.id]);
              const isCurrent = i === current;
              return (
                <li key={q.id}>
                  <button
                    type="button"
                    className={`qnav-btn ${isAnswered ? "answered" : ""} ${isCurrent ? "current" : ""}`}
                    onClick={() => setCurrent(i)}
                    aria-label={`Go to question ${i + 1}, ${isAnswered ? "answered" : "not answered"}`}
                    aria-current={isCurrent ? "step" : undefined}
                  >
                    {i + 1}
                  </button>
                </li>
              );
            })}
          </ol>
          <ul className="legend small muted">
            <li>
              <span className="legend-dot dot-current" /> Current
            </li>
            <li>
              <span className="legend-dot dot-answered" /> Answered
            </li>
            <li>
              <span className="legend-dot dot-open" /> Not answered
            </li>
          </ul>
          <button type="button" className="btn btn-accent btn-block" onClick={() => setConfirmSubmit(true)}>
            Submit quiz
          </button>
        </aside>
      </div>

      {confirmSubmit && (
        <ConfirmModal
          title="Submit your quiz?"
          confirmLabel={submitting ? "Submitting…" : "Yes, submit"}
          cancelLabel="Keep working"
          onConfirm={submit}
          onCancel={() => !submitting && setConfirmSubmit(false)}
        >
          <p>
            You have answered <strong>{answeredCount}</strong> of <strong>{total}</strong> questions.
          </p>
          {unanswered > 0 && (
            <p className="warning-text">
              <Icon name="alert" size={16} /> {unanswered} unanswered question{unanswered === 1 ? "" : "s"} will be marked
              incorrect.
            </p>
          )}
          <p>You cannot change your answers after submitting.</p>
        </ConfirmModal>
      )}

      {confirmExit && (
        <ConfirmModal
          title="Leave this quiz?"
          confirmLabel="Leave quiz"
          cancelLabel="Stay"
          danger
          onConfirm={() => navigate("/quizzes")}
          onCancel={() => setConfirmExit(false)}
        >
          <p>Your answers will not be saved and this attempt will not be recorded.</p>
        </ConfirmModal>
      )}
    </div>
  );
}
