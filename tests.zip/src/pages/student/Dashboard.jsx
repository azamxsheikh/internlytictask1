// Dashboard - the student's home page: welcome, key numbers, categories,
// recent attempts and a per-category progress overview.

import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useApp } from "../../context/AppContext.jsx";
import { useToast } from "../../context/ToastContext.jsx";
import { bestByCategory, computeStats } from "../../utils/scoring.js";
import { formatDate, formatPercent, greeting } from "../../utils/format.js";
import { validateStudentName } from "../../utils/validators.js";
import StatCard from "../../components/StatCard.jsx";
import CategoryCard from "../../components/CategoryCard.jsx";
import ProgressBar from "../../components/ProgressBar.jsx";
import EmptyState from "../../components/EmptyState.jsx";
import { PageLoader } from "../../components/Loader.jsx";
import Modal from "../../components/Modal.jsx";
import Field from "../../components/Field.jsx";
import Icon from "../../components/Icon.jsx";

export default function Dashboard() {
  const { loading, categories, questions, attempts, studentName, setStudentName } = useApp();
  const toast = useToast();
  const [editingName, setEditingName] = useState(false);

  const stats = useMemo(() => computeStats(attempts), [attempts]);
  const best = useMemo(() => bestByCategory(attempts), [attempts]);
  const counts = useMemo(() => {
    const map = {};
    questions.forEach((q) => {
      map[q.categoryId] = (map[q.categoryId] || 0) + 1;
    });
    return map;
  }, [questions]);

  if (loading) return <PageLoader label="Loading your dashboard" />;

  const recent = attempts.slice(0, 5);

  return (
    <>
      {/* Welcome */}
      <section className="hero card">
        <div>
          <p className="eyebrow">{greeting()}</p>
          <h1>Welcome back, {studentName}!</h1>
          <p className="hero-text">
            Test your HTML, CSS, JavaScript and React knowledge, review every answer and watch your scores improve.
          </p>
          <div className="hero-actions">
            <Link to="/quizzes" className="btn btn-accent">
              Take a quiz <Icon name="arrowRight" size={18} />
            </Link>
            <button type="button" className="btn btn-ghost" onClick={() => setEditingName(true)}>
              <Icon name="edit" size={16} /> Change name
            </button>
          </div>
        </div>
      </section>

      {/* Key numbers */}
      <section aria-labelledby="stats-heading" className="section">
        <h2 id="stats-heading" className="sr-only">
          Your statistics
        </h2>
        <div className="grid grid-4">
          <StatCard icon="quiz" label="Quizzes attempted" value={stats.total} tone="navy" />
          <StatCard icon="chart" label="Average score" value={stats.total ? formatPercent(stats.average) : "—"} tone="teal" />
          <StatCard icon="award" label="Best score" value={stats.total ? formatPercent(stats.best) : "—"} tone="gold" />
          <StatCard icon="check" label="Quizzes passed" value={stats.passed} hint="60% or higher" tone="green" />
        </div>
      </section>

      {/* Categories */}
      <section aria-labelledby="cat-heading" className="section">
        <div className="section-head">
          <h2 id="cat-heading">Available quiz categories</h2>
          <Link to="/quizzes" className="link-arrow">
            View all <Icon name="arrowRight" size={16} />
          </Link>
        </div>
        {categories.length === 0 ? (
          <div className="card">
            <EmptyState icon="layers" title="No categories available">
              An administrator has not created any quiz categories yet. Please check back later.
            </EmptyState>
          </div>
        ) : (
          <div className="grid grid-4">
            {categories.map((c) => (
              <CategoryCard key={c.id} category={c} questionCount={counts[c.id] || 0} bestScore={best[c.id]} />
            ))}
          </div>
        )}
      </section>

      <div className="grid grid-2 section">
        {/* Recent attempts */}
        <section className="card" aria-labelledby="recent-heading">
          <div className="section-head">
            <h2 id="recent-heading">Recent quiz attempts</h2>
            <Link to="/history" className="link-arrow">
              All history <Icon name="arrowRight" size={16} />
            </Link>
          </div>
          {recent.length === 0 ? (
            <EmptyState icon="history" title="No attempts yet">
              Your completed quizzes will appear here.
            </EmptyState>
          ) : (
            <ul className="recent-list">
              {recent.map((a) => (
                <li key={a.id}>
                  <Link to={`/result/${a.id}`} className="recent-item">
                    <div>
                      <p className="recent-title">{a.categoryName}</p>
                      <p className="small muted">{formatDate(a.date)}</p>
                    </div>
                    <div className="recent-score">
                      <strong>{formatPercent(a.percentage)}</strong>
                      <span className={`pill ${a.passed ? "pill-pass" : "pill-fail"}`}>{a.passed ? "Pass" : "Fail"}</span>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* Progress overview */}
        <section className="card" aria-labelledby="progress-heading">
          <h2 id="progress-heading">Progress overview</h2>
          {categories.length === 0 ? (
            <EmptyState icon="chart" title="Nothing to show yet" />
          ) : (
            <ul className="progress-list">
              {categories.map((c) => {
                const score = best[c.id];
                return (
                  <li key={c.id}>
                    <div className="progress-row">
                      <span>{c.name}</span>
                      <span className="small muted">{score === undefined ? "Not attempted" : `Best ${formatPercent(score)}`}</span>
                    </div>
                    <ProgressBar value={score ?? 0} label={`${c.name} best score`} tone={score >= 60 ? "teal" : "navy"} />
                  </li>
                );
              })}
            </ul>
          )}
          <p className="small muted note">Bars show your best score in each category. The pass mark is 60%.</p>
        </section>
      </div>

      {editingName && (
        <NameModal
          current={studentName}
          onClose={() => setEditingName(false)}
          onSave={(name) => {
            setStudentName(name);
            setEditingName(false);
            toast.success("Your name has been updated.");
          }}
        />
      )}
    </>
  );
}

function NameModal({ current, onSave, onClose }) {
  const [value, setValue] = useState(current);
  const [error, setError] = useState("");

  function handleSubmit(event) {
    event.preventDefault();
    const message = validateStudentName(value);
    setError(message);
    if (!message) onSave(value);
  }

  return (
    <Modal title="Change your display name" onClose={onClose}>
      <form onSubmit={handleSubmit} noValidate>
        <Field id="student-name" label="Display name" error={error} hint="2-30 characters" required>
          <input
            id="student-name"
            type="text"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            aria-invalid={Boolean(error)}
            aria-describedby="student-name-msg"
            autoComplete="name"
          />
        </Field>
        <div className="modal-actions">
          <button type="button" className="btn btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary">
            Save
          </button>
        </div>
      </form>
    </Modal>
  );
}
