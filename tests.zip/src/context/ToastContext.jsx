// ToastContext - friendly pop-up notifications ("Question saved", errors, ...).
// Usage in any component:  const toast = useToast();  toast.success("Saved!");

import { createContext, useCallback, useContext, useMemo, useState } from "react";
import { createId } from "../utils/storage.js";
import Icon from "../components/Icon.jsx";

const ToastContext = createContext(null);

const ICONS = { success: "check", error: "alert", info: "info" };

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);

  const remove = useCallback((id) => {
    setToasts((list) => list.filter((t) => t.id !== id));
  }, []);

  const push = useCallback(
    (type, message) => {
      const id = createId("toast");
      setToasts((list) => [...list.slice(-3), { id, type, message }]);
      setTimeout(() => remove(id), 4500);
    },
    [remove]
  );

  // useMemo keeps this object stable so components that use it don't re-render needlessly.
  const api = useMemo(
    () => ({
      success: (message) => push("success", message),
      error: (message) => push("error", message),
      info: (message) => push("info", message),
    }),
    [push]
  );

  return (
    <ToastContext.Provider value={api}>
      {children}
      {/* aria-live lets screen readers announce new notifications */}
      <div className="toast-region" aria-live="polite" aria-atomic="false">
        {toasts.map((t) => (
          <div key={t.id} className={`toast toast-${t.type}`} role={t.type === "error" ? "alert" : "status"}>
            <Icon name={ICONS[t.type]} size={18} />
            <span>{t.message}</span>
            <button type="button" className="toast-close" onClick={() => remove(t.id)} aria-label="Dismiss notification">
              <Icon name="x" size={16} />
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error("useToast must be used inside <ToastProvider>");
  return ctx;
}
