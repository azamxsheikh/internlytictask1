// AuthContext - DEMO-ONLY admin authentication.
//
// How it works:
//  1. The first time anyone opens /admin/login they create the demo admin
//     account (email + password). Only a salted SHA-256 hash is stored in
//     Local Storage - no password exists anywhere in the source code.
//  2. Logging in stores a short-lived marker in Session Storage (cleared when
//     the browser tab closes). <ProtectedRoute> checks it before showing any
//     /admin page.
//
// This keeps ordinary students out of the admin screens, but it is NOT secure:
// anyone can edit browser storage with the developer tools. Real
// authentication must happen on a server (see README).

import { createContext, useCallback, useContext, useMemo, useState } from "react";
import { STORAGE_KEYS, readJSON, writeJSON, removeKey, readSession, writeSession, removeSession } from "../utils/storage.js";
import { hashPassword, makeSalt } from "../utils/demoAuth.js";

const AuthContext = createContext(null);

const SESSION_KEY = "adminSession";
const SESSION_LENGTH_MS = 2 * 60 * 60 * 1000; // 2 hours

function readAccount() {
  const acc = readJSON(STORAGE_KEYS.admin, null);
  return acc && acc.email && acc.salt && acc.hash ? acc : null;
}

function readValidSession() {
  const s = readSession(SESSION_KEY);
  return s && typeof s.expires === "number" && s.expires > Date.now() ? s : null;
}

export function AuthProvider({ children }) {
  const [account, setAccount] = useState(readAccount);
  const [session, setSession] = useState(readValidSession);

  const startSession = useCallback((email) => {
    const s = { email, expires: Date.now() + SESSION_LENGTH_MS };
    writeSession(SESSION_KEY, s);
    setSession(s);
  }, []);

  /** First-time setup: create the demo admin and sign in. */
  const createAdmin = useCallback(
    async (email, password) => {
      try {
        const salt = makeSalt();
        const hash = await hashPassword(password, salt);
        const acc = { email: email.trim().toLowerCase(), salt, hash };
        if (!writeJSON(STORAGE_KEYS.admin, acc)) {
          return { ok: false, error: "Could not save the account. Browser storage is unavailable." };
        }
        setAccount(acc);
        startSession(acc.email);
        return { ok: true };
      } catch (err) {
        return { ok: false, error: err.message || "Something went wrong creating the account." };
      }
    },
    [startSession]
  );

  const login = useCallback(
    async (email, password) => {
      if (!account) return { ok: false, error: "No admin account exists yet." };
      try {
        const hash = await hashPassword(password, account.salt);
        const emailMatches = email.trim().toLowerCase() === account.email;
        // Same message for both cases so we don't reveal which part was wrong.
        if (!emailMatches || hash !== account.hash) {
          return { ok: false, error: "Invalid email or password." };
        }
        startSession(account.email);
        return { ok: true };
      } catch (err) {
        return { ok: false, error: err.message || "Could not sign in." };
      }
    },
    [account, startSession]
  );

  const logout = useCallback(() => {
    removeSession(SESSION_KEY);
    setSession(null);
  }, []);

  /** Forgot password? In this demo, wipe the account so a new one can be created. */
  const resetAdminAccount = useCallback(() => {
    removeKey(STORAGE_KEYS.admin);
    removeSession(SESSION_KEY);
    setAccount(null);
    setSession(null);
  }, []);

  const value = useMemo(
    () => ({
      hasAccount: Boolean(account),
      isAdmin: Boolean(session && session.expires > Date.now()),
      adminEmail: session?.email || "",
      createAdmin,
      login,
      logout,
      resetAdminAccount,
    }),
    [account, session, createAdmin, login, logout, resetAdminAccount]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>");
  return ctx;
}
