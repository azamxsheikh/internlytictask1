// AppContext - the app's "data store".
//
// It keeps categories, questions, quiz attempts and the student's name in React
// state and mirrors them to Local Storage so they survive a page refresh.
// Pages never touch Local Storage directly; they call the functions below.
// (If you later add a backend, this is the one file you would change to call
// your API instead of Local Storage.)

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { SEED_CATEGORIES, SEED_QUESTIONS } from "../data/seedData.js";
import { STORAGE_KEYS, readJSON, writeJSON, createId } from "../utils/storage.js";
import { slugify } from "../utils/validators.js";
import { useToast } from "./ToastContext.jsx";

const AppContext = createContext(null);

const MAX_SAVED_ATTEMPTS = 200; // keeps Local Storage from filling up

// Load a list from storage; if it is missing or corrupted, use the fallback.
function loadList(key, fallback) {
  const value = readJSON(key, null);
  return Array.isArray(value) ? value : fallback;
}

export function AppProvider({ children }) {
  const toast = useToast();

  const [categories, setCategories] = useState(() => loadList(STORAGE_KEYS.categories, SEED_CATEGORIES));
  const [questions, setQuestions] = useState(() => loadList(STORAGE_KEYS.questions, SEED_QUESTIONS));
  const [attempts, setAttempts] = useState(() => loadList(STORAGE_KEYS.attempts, []));
  const [studentName, setStudentNameState] = useState(() => {
    const saved = readJSON(STORAGE_KEYS.studentName, "Student");
    return typeof saved === "string" && saved.trim() ? saved : "Student";
  });
  const [loading, setLoading] = useState(true);

  // A short loading state so pages show their skeletons (and to mimic a real API call).
  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 450);
    return () => clearTimeout(timer);
  }, []);

  // Save to Local Storage whenever data changes. If saving fails, tell the user.
  const save = useCallback(
    (key, value) => {
      if (!writeJSON(key, value)) {
        toast.error("Could not save to browser storage. Your changes may be lost when you leave this page.");
      }
    },
    [toast]
  );
  useEffect(() => save(STORAGE_KEYS.categories, categories), [categories, save]);
  useEffect(() => save(STORAGE_KEYS.questions, questions), [questions, save]);
  useEffect(() => save(STORAGE_KEYS.attempts, attempts), [attempts, save]);
  useEffect(() => save(STORAGE_KEYS.studentName, studentName), [studentName, save]);

  // ------------------------------------------------------------- questions
  const addQuestion = useCallback((data) => {
    const question = { ...cleanQuestion(data), id: createId("q") };
    setQuestions((list) => [...list, question]);
    return question;
  }, []);

  const updateQuestion = useCallback((id, data) => {
    setQuestions((list) => list.map((q) => (q.id === id ? { ...cleanQuestion(data), id } : q)));
  }, []);

  const deleteQuestion = useCallback((id) => {
    setQuestions((list) => list.filter((q) => q.id !== id));
  }, []);

  // ------------------------------------------------------------ categories
  const addCategory = useCallback(
    (data) => {
      // Build a unique id from the name, e.g. "Node JS" -> "node-js".
      const base = slugify(data.name) || "category";
      let id = base;
      let n = 2;
      while (categories.some((c) => c.id === id)) id = `${base}-${n++}`;
      const category = {
        id,
        name: data.name.trim(),
        description: data.description.trim(),
        icon: data.icon,
      };
      setCategories((list) => [...list, category]);
      return category;
    },
    [categories]
  );

  const updateCategory = useCallback((id, data) => {
    setCategories((list) =>
      list.map((c) =>
        c.id === id
          ? { ...c, name: data.name.trim(), description: data.description.trim(), icon: data.icon }
          : c
      )
    );
  }, []);

  // Deleting a category also deletes its questions (the admin is warned first).
  const deleteCategory = useCallback((id) => {
    setCategories((list) => list.filter((c) => c.id !== id));
    setQuestions((list) => list.filter((q) => q.categoryId !== id));
  }, []);

  // -------------------------------------------------------------- attempts
  const saveAttempt = useCallback((attempt) => {
    setAttempts((list) => [attempt, ...list].slice(0, MAX_SAVED_ATTEMPTS));
  }, []);

  const clearHistory = useCallback(() => setAttempts([]), []);

  // ------------------------------------------------------------- misc
  const setStudentName = useCallback((name) => setStudentNameState(name.trim()), []);

  /** Restore the original demo categories and questions (history is kept). */
  const resetDemoData = useCallback(() => {
    setCategories(SEED_CATEGORIES);
    setQuestions(SEED_QUESTIONS);
  }, []);

  const value = useMemo(
    () => ({
      loading,
      categories,
      questions,
      attempts,
      studentName,
      addQuestion,
      updateQuestion,
      deleteQuestion,
      addCategory,
      updateCategory,
      deleteCategory,
      saveAttempt,
      clearHistory,
      setStudentName,
      resetDemoData,
    }),
    [
      loading, categories, questions, attempts, studentName,
      addQuestion, updateQuestion, deleteQuestion, addCategory, updateCategory,
      deleteCategory, saveAttempt, clearHistory, setStudentName, resetDemoData,
    ]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

// Keep only the fields we store and trim the text.
function cleanQuestion(data) {
  return {
    categoryId: data.categoryId,
    text: data.text.trim(),
    options: data.options.map((o) => o.trim()),
    correctIndex: data.correctIndex,
    topic: data.topic.trim(),
    explanation: (data.explanation || "").trim(),
  };
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used inside <AppProvider>");
  return ctx;
}
