// ---------------------------------------------------------------------------
// storage.js - thin, safe wrapper around the browser's Local Storage.
//
// Why a wrapper? Local Storage can be unavailable (private mode, blocked by
// the browser), full (about 5 MB limit) or contain corrupted text. Every
// function here catches those errors so the app never crashes because of
// storage problems.
//
// IMPORTANT LIMITATION: Local Storage lives only in ONE browser on ONE device.
// Clearing site data, switching browsers or using a private window removes it,
// and it is never shared between students. A real deployment needs a backend
// database (see README -> Future improvements).
// ---------------------------------------------------------------------------

// All keys are prefixed so we never collide with other apps on the same origin.
const PREFIX = "internlytic:v1:";

export const STORAGE_KEYS = {
  categories: "categories",
  questions: "questions",
  attempts: "attempts",
  studentName: "studentName",
  admin: "adminAccount",
};

function getLocal() {
  try {
    return globalThis.localStorage ?? null;
  } catch {
    return null; // Access itself can throw when storage is blocked.
  }
}

function getSession() {
  try {
    return globalThis.sessionStorage ?? null;
  } catch {
    return null;
  }
}

/** Read and parse a JSON value. Returns `fallback` if missing or corrupted. */
export function readJSON(key, fallback) {
  const store = getLocal();
  if (!store) return fallback;
  try {
    const raw = store.getItem(PREFIX + key);
    return raw === null ? fallback : JSON.parse(raw);
  } catch {
    return fallback;
  }
}

/** Save a value as JSON. Returns true on success, false if saving failed. */
export function writeJSON(key, value) {
  const store = getLocal();
  if (!store) return false;
  try {
    store.setItem(PREFIX + key, JSON.stringify(value));
    return true;
  } catch {
    return false; // Quota exceeded or storage blocked.
  }
}

export function removeKey(key) {
  const store = getLocal();
  if (!store) return;
  try {
    store.removeItem(PREFIX + key);
  } catch {
    /* ignore */
  }
}

/** Remove every key that belongs to this app (used by "reset" actions). */
export function clearAllAppData() {
  const store = getLocal();
  if (!store) return;
  try {
    Object.keys(store)
      .filter((k) => k.startsWith(PREFIX))
      .forEach((k) => store.removeItem(k));
  } catch {
    /* ignore */
  }
}

// --- Session storage: used for the demo admin login (cleared when the tab closes)

export function readSession(key) {
  const store = getSession();
  if (!store) return null;
  try {
    const raw = store.getItem(PREFIX + key);
    return raw === null ? null : JSON.parse(raw);
  } catch {
    return null;
  }
}

export function writeSession(key, value) {
  const store = getSession();
  if (!store) return false;
  try {
    store.setItem(PREFIX + key, JSON.stringify(value));
    return true;
  } catch {
    return false;
  }
}

export function removeSession(key) {
  const store = getSession();
  if (!store) return;
  try {
    store.removeItem(PREFIX + key);
  } catch {
    /* ignore */
  }
}

/** Create a reasonably unique id such as "q-1f3a9c...". */
export function createId(prefix = "id") {
  const random =
    globalThis.crypto && typeof globalThis.crypto.randomUUID === "function"
      ? globalThis.crypto.randomUUID().slice(0, 8)
      : Math.random().toString(36).slice(2, 10);
  return `${prefix}-${Date.now().toString(36)}${random}`;
}
