// ---------------------------------------------------------------------------
// scoring.js - pure functions that calculate quiz results.
// "Pure" means: same input -> same output, no side effects. That makes them
// easy to test (see tests/logic.test.mjs).
// ---------------------------------------------------------------------------

/** A student passes with 60% or more. Change it here to change it everywhere. */
export const PASS_PERCENTAGE = 60;

/** Each correct answer is worth one mark. */
export const MARKS_PER_QUESTION = 1;

/**
 * Score a quiz.
 * @param {Array} questions  the questions that were shown, in order
 * @param {Object} answers   map of questionId -> selected option index
 */
export function scoreQuiz(questions, answers) {
  const review = questions.map((q) => {
    const selected = Number.isInteger(answers[q.id]) ? answers[q.id] : null;
    return {
      questionId: q.id,
      text: q.text,
      options: [...q.options],
      selectedIndex: selected,
      correctIndex: q.correctIndex,
      isCorrect: selected === q.correctIndex,
      topic: q.topic,
      explanation: q.explanation || "",
    };
  });

  const total = review.length;
  const correct = review.filter((r) => r.isCorrect).length;
  const unanswered = review.filter((r) => r.selectedIndex === null).length;
  const percentage = total === 0 ? 0 : Math.round((correct / total) * 1000) / 10;

  return {
    total,
    correct,
    // Unanswered questions count as incorrect.
    incorrect: total - correct,
    unanswered,
    marks: correct * MARKS_PER_QUESTION,
    totalMarks: total * MARKS_PER_QUESTION,
    percentage,
    passed: percentage >= PASS_PERCENTAGE,
    review,
  };
}

/** Friendly performance text for the result page. */
export function getPerformanceSummary(percentage) {
  if (percentage >= 90) {
    return {
      level: "Outstanding",
      message:
        "Excellent work! You have a very strong command of this topic. Try the other categories to keep your skills well-rounded.",
    };
  }
  if (percentage >= 75) {
    return {
      level: "Very good",
      message:
        "Great result. You understand most of the concepts - review the few missed questions to close the remaining gaps.",
    };
  }
  if (percentage >= PASS_PERCENTAGE) {
    return {
      level: "Good",
      message:
        "You passed. Your foundation is solid, and some focused practice on the topics below will raise your score.",
    };
  }
  if (percentage >= 40) {
    return {
      level: "Needs improvement",
      message:
        "You are getting there, but not yet at the pass mark. Read the explanations in the review and try the quiz again.",
    };
  }
  return {
    level: "Keep practising",
    message:
      "Do not be discouraged - everyone starts somewhere. Study the topics listed below, then retake the quiz.",
  };
}

/**
 * Which topics need more practice? Counts wrong answers per topic and
 * returns only topics with at least one mistake, worst first.
 */
export function topicsToPractice(review) {
  const map = new Map();
  review.forEach((item) => {
    const entry = map.get(item.topic) || { topic: item.topic, wrong: 0, total: 0 };
    entry.total += 1;
    if (!item.isCorrect) entry.wrong += 1;
    map.set(item.topic, entry);
  });
  return [...map.values()]
    .filter((t) => t.wrong > 0)
    .sort((a, b) => b.wrong - a.wrong || a.topic.localeCompare(b.topic));
}

/** Overall statistics for the student dashboard. */
export function computeStats(attempts) {
  const total = attempts.length;
  if (total === 0) return { total: 0, average: 0, best: 0, passed: 0 };
  const sum = attempts.reduce((acc, a) => acc + a.percentage, 0);
  return {
    total,
    average: Math.round((sum / total) * 10) / 10,
    best: Math.max(...attempts.map((a) => a.percentage)),
    passed: attempts.filter((a) => a.passed).length,
  };
}

/** Best percentage per category id, e.g. { html: 80, css: 60 }. */
export function bestByCategory(attempts) {
  const best = {};
  attempts.forEach((a) => {
    if (best[a.categoryId] === undefined || a.percentage > best[a.categoryId]) {
      best[a.categoryId] = a.percentage;
    }
  });
  return best;
}
