// ---------------------------------------------------------------------------
// demoAuth.js - helpers for the DEMO-ONLY admin login.
//
// !!! THIS IS NOT REAL SECURITY !!!
// Everything runs in the visitor's browser, so a determined user can open the
// developer tools and bypass it. It only keeps ordinary students out of the
// admin screens. Production apps must verify credentials on a server
// (Express + hashed passwords + JWT/session cookies) and authorise every
// admin API request on the server. No password is stored in the source code:
// the first visitor creates the demo admin account, and only a salted hash of
// the password is kept in Local Storage.
// ---------------------------------------------------------------------------

function toHex(buffer) {
  return [...new Uint8Array(buffer)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

/** Random salt so identical passwords do not produce identical hashes. */
export function makeSalt() {
  const bytes = new Uint8Array(16);
  globalThis.crypto.getRandomValues(bytes);
  return toHex(bytes);
}

/** SHA-256(salt + password) using the browser's Web Crypto API. */
export async function hashPassword(password, salt) {
  if (!globalThis.crypto || !globalThis.crypto.subtle) {
    throw new Error(
      "Secure hashing is not available. Open the app on https:// or http://localhost."
    );
  }
  const data = new TextEncoder().encode(`${salt}:${password}`);
  const digest = await globalThis.crypto.subtle.digest("SHA-256", data);
  return toHex(digest);
}
