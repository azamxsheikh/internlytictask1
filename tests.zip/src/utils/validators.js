// ---------------------------------------------------------------------------
// validators.js - form validation rules in one place.
// Every validator returns an object of error messages keyed by field name.
// An empty object ({}) means the form is valid.
// ---------------------------------------------------------------------------

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export function isValidEmail(value) {
  return EMAIL_PATTERN.test(String(value || "").trim());
}

/** Validate a question coming from the admin form. */
export function validateQuestion(data, categories) {
  const errors = {};
  const text = (data.text || "").trim();
  const topic = (data.topic || "").trim();
  const explanation = (data.explanation || "").trim();
  const options = (data.options || []).map((o) => (o || "").trim());

  if (!data.categoryId || !categories.some((c) => c.id === data.categoryId)) {
    errors.categoryId = "Please choose a category.";
  }

  if (text.length < 10) errors.text = "The question must be at least 10 characters long.";
  else if (text.length > 300) errors.text = "The question must be 300 characters or fewer.";

  if (options.length !== 4) {
    errors.options = "Exactly four answer options are required.";
  } else {
    const optionErrors = options.map((o) => {
      if (!o) return "This option cannot be empty.";
      if (o.length > 150) return "Keep each option under 150 characters.";
      return "";
    });
    // Duplicate options would make the question unfair, so reject them.
    const seen = new Map();
    options.forEach((o, i) => {
      const key = o.toLowerCase();
      if (!o) return;
      if (seen.has(key)) {
        if (!optionErrors[i]) optionErrors[i] = "Options must be different from each other.";
      } else {
        seen.set(key, i);
      }
    });
    if (optionErrors.some(Boolean)) errors.options = optionErrors;
  }

  if (!Number.isInteger(data.correctIndex) || data.correctIndex < 0 || data.correctIndex > 3) {
    errors.correctIndex = "Select which option is the correct answer.";
  }

  if (topic.length < 2) errors.topic = "Enter the topic (at least 2 characters), e.g. Flexbox.";
  else if (topic.length > 40) errors.topic = "The topic must be 40 characters or fewer.";

  if (explanation.length > 300) errors.explanation = "The explanation must be 300 characters or fewer.";

  return errors;
}

/** Validate a category. `editingId` lets a category keep its own name. */
export function validateCategory(data, categories, editingId = null) {
  const errors = {};
  const name = (data.name || "").trim();
  const description = (data.description || "").trim();

  if (name.length < 2) errors.name = "The name must be at least 2 characters long.";
  else if (name.length > 30) errors.name = "The name must be 30 characters or fewer.";
  else if (
    categories.some((c) => c.id !== editingId && c.name.toLowerCase() === name.toLowerCase())
  ) {
    errors.name = "A category with this name already exists.";
  }

  if (description.length < 10) errors.description = "The description must be at least 10 characters long.";
  else if (description.length > 150) errors.description = "The description must be 150 characters or fewer.";

  if (!data.icon) errors.icon = "Please choose an icon.";

  return errors;
}

/** Validate the student display name. */
export function validateStudentName(name) {
  const value = (name || "").trim();
  if (value.length < 2) return "Your name must be at least 2 characters long.";
  if (value.length > 30) return "Your name must be 30 characters or fewer.";
  return "";
}

/** Validate the demo-admin login / setup form. */
export function validateAdminForm({ email, password, confirm }, isSetup) {
  const errors = {};
  if (!isValidEmail(email)) errors.email = "Enter a valid email address.";

  if (!password) {
    errors.password = "Enter a password.";
  } else if (isSetup) {
    if (password.length < 8) errors.password = "Use at least 8 characters.";
    else if (!/[A-Za-z]/.test(password) || !/\d/.test(password)) {
      errors.password = "Include at least one letter and one number.";
    }
    if (confirm !== password) errors.confirm = "The passwords do not match.";
  }
  return errors;
}

/** Turn a category name into a URL-friendly id ("Node JS" -> "node-js"). */
export function slugify(text) {
  return String(text)
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}
