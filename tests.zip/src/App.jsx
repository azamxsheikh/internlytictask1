// App.jsx - the route table. Each <Route> maps a URL to a page component.
//
//   /                      Student dashboard
//   /quizzes               Choose a quiz category
//   /quiz/:categoryId      Take a quiz
//   /result/:attemptId     Result + answer review
//   /history               Attempt history
//   /admin/login           Admin sign-in (public)
//   /admin/...             Admin pages (protected by <ProtectedRoute>)

import { Route, Routes } from "react-router-dom";
import StudentLayout from "./components/layouts/StudentLayout.jsx";
import AdminLayout from "./components/layouts/AdminLayout.jsx";
import ProtectedRoute from "./components/ProtectedRoute.jsx";

import Dashboard from "./pages/student/Dashboard.jsx";
import Quizzes from "./pages/student/Quizzes.jsx";
import Quiz from "./pages/student/Quiz.jsx";
import Result from "./pages/student/Result.jsx";
import History from "./pages/student/History.jsx";

import AdminLogin from "./pages/admin/AdminLogin.jsx";
import AdminDashboard from "./pages/admin/AdminDashboard.jsx";
import ManageQuestions from "./pages/admin/ManageQuestions.jsx";
import ManageCategories from "./pages/admin/ManageCategories.jsx";

import NotFound from "./pages/NotFound.jsx";

export default function App() {
  return (
    <Routes>
      {/* Student area */}
      <Route element={<StudentLayout />}>
        <Route index element={<Dashboard />} />
        <Route path="quizzes" element={<Quizzes />} />
        <Route path="quiz/:categoryId" element={<Quiz />} />
        <Route path="result/:attemptId" element={<Result />} />
        <Route path="history" element={<History />} />
      </Route>

      {/* Admin area */}
      <Route path="admin/login" element={<AdminLogin />} />
      <Route
        path="admin"
        element={
          <ProtectedRoute>
            <AdminLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<AdminDashboard />} />
        <Route path="questions" element={<ManageQuestions />} />
        <Route path="categories" element={<ManageCategories />} />
      </Route>

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
